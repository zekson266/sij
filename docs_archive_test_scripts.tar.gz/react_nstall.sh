cd ~/booker/frontend
npm install
npm run dev
