#!/usr/bin/env python3
"""
Simple test script to verify the new settings architecture.

Tests:
1. Backend tenant service reads from module_config structure
2. No backward compatibility code is used
3. Settings structure is clean and correct

Usage:
    python test_settings_architecture.py
"""

import sys
import json
from typing import Dict, Any

# Mock tenant objects for testing
def create_test_tenant_with_new_structure() -> Dict[str, Any]:
    """Create a tenant with the new module_config structure."""
    return {
        "id": "test-tenant-1",
        "settings": {
            "modules": {
                "booking": True,
                "ropa": True
            },
            "module_config": {
                "booking": {
                    "services": [
                        {"value": "consultation", "label": "Consultation", "is_default": True},
                        {"value": "follow-up", "label": "Follow-up", "is_default": False}
                    ]
                },
                "ropa": {
                    "defaults": {
                        "default_retention_period": "5 years",
                        "default_legal_basis": "consent",
                        "default_deletion_method": "secure_deletion"
                    },
                    "ai_preferences": {
                        "enabled": True,
                        "model_preference": "gpt-4o-mini",
                        "include_company_context": True
                    }
                }
            }
        },
        "tenant_metadata": {
            "company": {
                "industry": "Healthcare",
                "sector": "Medical Services",
                "legal_jurisdiction": ["EU", "UK"],
                "company_size": "medium",
                "primary_country": "United Kingdom",
                "dpo": {
                    "name": "John Doe",
                    "email": "dpo@example.com",
                    "phone": "+44 123 456 7890"
                },
                "compliance_frameworks": ["GDPR", "HIPAA"]
            }
        }
    }

def create_test_tenant_without_config() -> Dict[str, Any]:
    """Create a tenant without module_config (should use defaults)."""
    return {
        "id": "test-tenant-2",
        "settings": {
            "modules": {
                "booking": True,
                "ropa": True
            }
        },
        "tenant_metadata": {}
    }

def test_booking_services_structure(tenant: Dict[str, Any]) -> bool:
    """Test that booking services are read from module_config.booking.services."""
    print(f"\n📋 Testing booking services for tenant: {tenant['id']}")
    
    settings = tenant.get("settings", {})
    module_config = settings.get("module_config", {})
    booking_config = module_config.get("booking", {})
    services = booking_config.get("services")
    
    if services:
        print(f"  ✅ Found {len(services)} booking services in module_config.booking.services")
        for service in services:
            print(f"     - {service.get('label')} ({service.get('value')})")
        return True
    else:
        print(f"  ✅ No services configured, will use defaults (expected behavior)")
        return True

def test_ropa_settings_structure(tenant: Dict[str, Any]) -> bool:
    """Test that ROPA settings are read from module_config.ropa."""
    print(f"\n📋 Testing ROPA settings for tenant: {tenant['id']}")
    
    settings = tenant.get("settings", {})
    module_config = settings.get("module_config", {})
    ropa_config = module_config.get("ropa", {})
    
    if ropa_config:
        defaults = ropa_config.get("defaults", {})
        ai_prefs = ropa_config.get("ai_preferences", {})
        
        print(f"  ✅ Found ROPA settings in module_config.ropa")
        if defaults:
            print(f"     - Defaults: {json.dumps(defaults, indent=6)}")
        if ai_prefs:
            print(f"     - AI Preferences: {json.dumps(ai_prefs, indent=6)}")
        return True
    else:
        print(f"  ✅ No ROPA settings configured (expected for new tenants)")
        return True

def test_company_context_structure(tenant: Dict[str, Any]) -> bool:
    """Test that company context is read from tenant_metadata.company."""
    print(f"\n📋 Testing company context for tenant: {tenant['id']}")
    
    metadata = tenant.get("tenant_metadata", {})
    company = metadata.get("company", {})
    
    if company:
        print(f"  ✅ Found company context in tenant_metadata.company")
        print(f"     - Industry: {company.get('industry', 'N/A')}")
        print(f"     - Sector: {company.get('sector', 'N/A')}")
        print(f"     - Company Size: {company.get('company_size', 'N/A')}")
        if company.get("dpo"):
            print(f"     - DPO: {company['dpo'].get('name', 'N/A')}")
        return True
    else:
        print(f"  ✅ No company context configured (expected for new tenants)")
        return True

def test_no_old_structure_references(tenant: Dict[str, Any]) -> bool:
    """Test that no old structure references exist."""
    print(f"\n📋 Checking for old structure references in tenant: {tenant['id']}")
    
    settings = tenant.get("settings", {})
    
    # Check for old booking structure
    if "booking" in settings and isinstance(settings["booking"], dict) and "services" in settings["booking"]:
        print(f"  ❌ Found old structure: settings.booking.services (should not exist)")
        return False
    
    # Check for old modules.booking structure (as object, not boolean)
    modules = settings.get("modules", {})
    if isinstance(modules, dict):
        booking_module = modules.get("booking")
        if isinstance(booking_module, dict) and "services" in booking_module:
            print(f"  ❌ Found old structure: settings.modules.booking.services (should not exist)")
            return False
    
    # Check for old modules.ropa structure (as object with settings)
    if isinstance(modules, dict):
        ropa_module = modules.get("ropa")
        if isinstance(ropa_module, dict) and ("defaults" in ropa_module or "ai_preferences" in ropa_module):
            print(f"  ❌ Found old structure: settings.modules.ropa (should not exist)")
            return False
    
    print(f"  ✅ No old structure references found")
    return True

def main():
    """Run all tests."""
    print("=" * 60)
    print("🧪 Testing Settings Architecture")
    print("=" * 60)
    
    tests_passed = 0
    tests_failed = 0
    
    # Test tenant with new structure
    tenant1 = create_test_tenant_with_new_structure()
    
    if test_booking_services_structure(tenant1):
        tests_passed += 1
    else:
        tests_failed += 1
    
    if test_ropa_settings_structure(tenant1):
        tests_passed += 1
    else:
        tests_failed += 1
    
    if test_company_context_structure(tenant1):
        tests_passed += 1
    else:
        tests_failed += 1
    
    if test_no_old_structure_references(tenant1):
        tests_passed += 1
    else:
        tests_failed += 1
    
    # Test tenant without config (should use defaults)
    tenant2 = create_test_tenant_without_config()
    
    if test_booking_services_structure(tenant2):
        tests_passed += 1
    else:
        tests_failed += 1
    
    if test_ropa_settings_structure(tenant2):
        tests_passed += 1
    else:
        tests_failed += 1
    
    if test_no_old_structure_references(tenant2):
        tests_passed += 1
    else:
        tests_failed += 1
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Summary")
    print("=" * 60)
    print(f"✅ Tests Passed: {tests_passed}")
    print(f"❌ Tests Failed: {tests_failed}")
    print(f"📈 Total Tests: {tests_passed + tests_failed}")
    
    if tests_failed == 0:
        print("\n🎉 All tests passed! Settings architecture is clean.")
        return 0
    else:
        print("\n⚠️  Some tests failed. Please review the output above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())

