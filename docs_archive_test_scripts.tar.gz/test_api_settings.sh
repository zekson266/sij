#!/bin/bash
# Simple API test script for settings architecture
# Tests that the API correctly uses module_config structure

set -e

API_URL="${API_URL:-http://localhost/api}"
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "============================================================"
echo "🧪 Testing Settings Architecture via API"
echo "============================================================"
echo ""

# Check if API is accessible
echo "📡 Checking API health..."
if curl -s -f "${API_URL}/health" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ API is accessible${NC}"
else
    echo -e "${RED}❌ API is not accessible. Is the backend running?${NC}"
    echo "   Try: docker compose restart backend"
    exit 1
fi

echo ""
echo "============================================================"
echo "📝 Test Instructions"
echo "============================================================"
echo ""
echo "This script verifies the API is running. For full testing:"
echo ""
echo "1. Manual UI Testing:"
echo "   - Login to the application"
echo "   - Navigate to Tenant Settings → Booking tab"
echo "   - Add/modify booking services"
echo "   - Verify they save to: settings.module_config.booking.services"
echo ""
echo "2. Navigate to Tenant Settings → ROPA Settings tab"
echo "   - Fill in company context"
echo "   - Configure ROPA defaults and AI preferences"
echo "   - Verify they save to: settings.module_config.ropa"
echo ""
echo "3. Check Database (optional):"
echo "   docker compose exec db psql -U postgres -d bangbang -c \""
echo "   SELECT id, settings->'module_config' FROM tenants LIMIT 1;\""
echo ""
echo "4. Verify Code Structure:"
echo "   - Run: python3 test_settings_architecture.py"
echo "   - Check that no old structure references exist"
echo ""
echo -e "${GREEN}✅ API health check passed${NC}"
echo ""
echo "============================================================"
echo "🎯 Next Steps"
echo "============================================================"
echo ""
echo "1. Test in UI: http://localhost (or your configured domain)"
echo "2. Verify settings save correctly"
echo "3. Check browser console for any errors"
echo "4. Verify RBAC permissions work for ROPA module"
echo ""

