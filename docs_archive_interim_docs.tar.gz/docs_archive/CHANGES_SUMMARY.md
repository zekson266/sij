# Subdomain Routing Implementation - Changes Summary

## Overview
Implemented subdomain-based routing for tenant public pages (e.g., `huy.onebrat.xyz` displays tenant public page).

## Changes Made

### 1. Frontend Code

#### New Files:
- **`frontend/src/utils/subdomain.ts`**
  - Subdomain detection utility
  - Extracts tenant slug from subdomain (e.g., `huy.onebrat.xyz` → `huy`)
  - Handles reserved subdomains (www, api, admin, etc.)
  - Main domain: `onebrat.xyz`

#### Modified Files:
- **`frontend/src/App.tsx`**
  - Added subdomain detection using `isTenantSubdomain()`
  - Root route (`/`) conditionally renders `TenantPublicPage` on subdomains, `LandingPage` on main domain
  - AppBar hidden on tenant subdomains for cleaner public pages
  - Removed all debug code (banner, console logs, window debug properties)

- **`frontend/src/pages/TenantPublicPage.tsx`** (renamed from `TenantBookingPage.tsx`)
  - Renamed component to better reflect its purpose
  - Updated to prioritize subdomain slug over URL param
  - Supports both subdomain (`huy.onebrat.xyz`) and URL path (`/book/huy`) access
  - Login redirect preserves subdomain context

- **`frontend/src/pages/index.ts`**
  - Updated export from `TenantBookingPage` to `TenantPublicPage`

### 2. Infrastructure

#### Modified Files:
- **`nginx/default.conf.template`**
  - Added wildcard subdomain server block (`*.${DOMAIN_NAME}`)
  - HTTP → HTTPS redirect for subdomains
  - Cache-busting headers for HTML and JS files (prevents browser caching issues)
  - Serves React SPA for all subdomains

- **`install.sh`**
  - Updated SSL certificate acquisition to support wildcard certificates
  - Added DNS-01 challenge option for wildcard SSL (`*.onebrat.xyz`)
  - Improved certificate generation error handling

### 3. Build & Verification Tools

#### New Files:
- **`scripts/verify-build.sh`**
  - Automated build verification script
  - Checks TypeScript compilation
  - Verifies build output exists
  - Validates bundle size
  - Can search for specific code in bundle

- **`.ai-instructions.md`**
  - Instructions for AI assistants
  - Build verification checklist
  - Common error patterns and fixes
  - Quick reference commands

- **`BUILD_CHECKLIST.md`**
  - Step-by-step build verification process
  - Common issues and solutions
  - Quick check commands

### 4. Removed Files
- `frontend/src/pages/TenantBookingPage.tsx` (renamed to `TenantPublicPage.tsx`)

## Technical Details

### Subdomain Detection Logic
1. Extracts subdomain from `window.location.hostname`
2. Validates against main domain (`onebrat.xyz`)
3. Checks against reserved subdomains list
4. Returns tenant slug or `null`

### Routing Behavior
- **Main domain** (`onebrat.xyz`): Shows `LandingPage`
- **Subdomain** (`huy.onebrat.xyz`): Shows `TenantPublicPage` for tenant "huy"
- **URL path** (`/book/huy`): Still works as fallback, shows `TenantPublicPage`

### Build Fixes
- Fixed TypeScript compilation errors (window property type assertions)
- Removed all debug code (console logs, debug banners, window debug properties)
- Code is production-ready

## Testing

### Verified:
- ✅ TypeScript compilation succeeds
- ✅ Frontend build completes successfully
- ✅ Subdomain detection works (`huy.onebrat.xyz` shows tenant page)
- ✅ Main domain still shows landing page
- ✅ `/book/:slug` route still works as fallback
- ✅ AppBar hidden on subdomains
- ✅ No debug code in production build

## Deployment Notes

### DNS Setup (Already Complete):
- Wildcard DNS record: `*.onebrat.xyz` → server IP

### SSL Setup (Already Complete):
- Wildcard SSL certificate: `*.onebrat.xyz`
- Certificate stored in `ssl/` directory

### Next Steps:
1. Rebuild frontend: `docker compose build frontend-build`
2. Restart nginx: `docker compose restart nginx`
3. Test subdomain: Visit `huy.onebrat.xyz` (or any tenant slug)

## Files Changed Summary

```
Modified:
- frontend/src/App.tsx
- frontend/src/pages/index.ts
- nginx/default.conf.template
- install.sh

Added:
- frontend/src/utils/subdomain.ts
- frontend/src/pages/TenantPublicPage.tsx
- scripts/verify-build.sh
- .ai-instructions.md
- BUILD_CHECKLIST.md

Removed:
- frontend/src/pages/TenantBookingPage.tsx
```

## Commit Message Suggestion

```
feat: Implement subdomain routing for tenant public pages

- Add subdomain detection utility (frontend/src/utils/subdomain.ts)
- Update App.tsx to conditionally render TenantPublicPage on subdomains
- Rename TenantBookingPage to TenantPublicPage for clarity
- Configure nginx for wildcard subdomain support
- Add build verification tools and documentation
- Remove all debug code, production-ready

Supports both subdomain (huy.onebrat.xyz) and URL path (/book/huy) access.
```




