# Module Architecture Analysis

**Date:** 2026-01-03  
**Status:** Analysis Complete - Implementation Pending

## Overview

This document analyzes the current modular architecture and identifies impacts, issues, and recommendations for adding/removing modules in the application.

## Current Architecture

### Backend Module System

#### Module Registration
- **Location:** `backend/app/main.py`
- **Method:** Hardcoded imports and router registration
```python
from .modules.booker import routers as booker_routers
from .modules.ropa import routers as ropa_routers
app.include_router(booker_routers.router)
app.include_router(ropa_routers.router)
```

#### Module Enablement
- **Storage:** `tenant.settings.modules` (JSONB field)
- **Structure:** `{"booker": true, "ropa": false}`
- **Default:** `booker` is enabled by default for backward compatibility
- **Enforcement:** `require_module()` dependency in routes
- **Behavior:** Returns 404 if module not enabled (hides module existence)

#### Route Protection
- All module routes are **always registered** at application startup
- Routes are protected by `require_module()` dependency
- Disabled modules return 404 (not 403) to hide module existence
- Routes exist but are inaccessible if module is disabled

### Frontend Module System

#### Module Structure
- **Location:** `frontend/src/modules/{module_name}/`
- **Organization:** Each module has `components/`, `services/`, `types/`, `pages/`
- **Import Pattern:** Direct imports from module paths

#### Current Usage
- **Hardcoded:** Pages directly import module components
  - `TenantOwnerPage` imports `AppointmentManagementForm` from booker
  - `TenantPublicPage` imports `BookingForm` from booker
- **No Enablement Checks:** Frontend doesn't check `tenant.settings.modules`
- **No Conditional Rendering:** Components render regardless of module status

### Database

#### Table Persistence
- Module tables exist regardless of enablement status
- Data persists even when module is disabled
- No automatic cleanup on module disablement
- Cascade deletes work correctly when enabled

## Impact Analysis

### Adding a New Module

#### Required Changes
1. **Backend:**
   - Create module directory structure (`models/`, `schemas/`, `services/`, `routers.py`)
   - Add import in `main.py`: `from .modules.{module} import routers as {module}_routers`
   - Add router registration: `app.include_router({module}_routers.router)`
   - Create database migration for new tables
   - Update `alembic/env.py` to import new models

2. **Frontend:**
   - Create module directory structure (`components/`, `services/`, `types/`, `pages/`)
   - Import and use components in pages
   - Add routes if needed in `App.tsx`

3. **Configuration:**
   - No changes needed - module enablement is per-tenant via settings

#### Impact
- ✅ **No Breaking Changes:** Existing modules unaffected
- ✅ **Backward Compatible:** New module disabled by default
- ⚠️ **Code Changes Required:** Manual registration in `main.py`
- ⚠️ **Bundle Size:** Frontend bundle includes all modules

### Removing a Module

#### Required Changes
1. **Backend:**
   - Remove import from `main.py`
   - Remove router registration
   - Remove module directory (optional - can keep for data preservation)
   - Update `alembic/env.py` to remove model imports

2. **Frontend:**
   - Remove component imports from pages
   - Remove module directory
   - Remove routes from `App.tsx` if any

3. **Database:**
   - Tables remain (data preserved)
   - Optional: Create migration to drop tables if desired

#### Impact
- ❌ **Breaking Change:** Tenants using the module lose access
- ❌ **Data Loss Risk:** If tables are dropped, data is lost
- ⚠️ **Code Cleanup:** Manual removal required
- ✅ **Data Preservation:** If tables kept, data remains accessible

### Disabling a Module (Per-Tenant)

#### Current Behavior
1. **Backend:**
   - ✅ Routes return 404 (works correctly)
   - ✅ Module existence is hidden
   - ✅ Data remains in database

2. **Frontend:**
   - ❌ Components still render (problem)
   - ❌ API calls fail with 404 (poor UX)
   - ❌ No indication module is disabled
   - ❌ No graceful degradation

3. **Database:**
   - ✅ Data remains intact
   - ✅ No data loss

#### Impact
- ⚠️ **Backend Works:** Module protection functions correctly
- ❌ **Frontend Broken:** UI doesn't respect module enablement
- ⚠️ **Poor UX:** Users see components but get errors

## Problems Identified

### Critical Issues

1. **Frontend Doesn't Check Module Enablement**
   - **Problem:** Components render even when module is disabled
   - **Impact:** Users see UI but get 404 errors on API calls
   - **Location:** `TenantOwnerPage`, `TenantPublicPage`
   - **Example:** Booking form shows even if booker module is disabled

2. **No Graceful Degradation**
   - **Problem:** No "Module not enabled" messages
   - **Impact:** Confusing user experience
   - **Solution Needed:** Conditional rendering based on enablement

3. **Hardcoded Module Dependencies**
   - **Problem:** Pages directly import module components
   - **Impact:** Not truly modular at UI level
   - **Example:** `import { BookingForm } from '../modules/booker/components'`

### Medium Priority Issues

4. **Manual Module Registration**
   - **Problem:** Must manually add imports in `main.py`
   - **Impact:** Easy to forget when adding new modules
   - **Solution:** Auto-discovery from directory structure

5. **No Module Status in API Responses**
   - **Problem:** Frontend must infer module status from tenant settings
   - **Impact:** Inconsistent enablement checking
   - **Solution:** Include `enabled_modules` in tenant API responses

6. **Bundle Size**
   - **Problem:** All modules included in frontend bundle
   - **Impact:** Larger bundle size even for tenants without modules
   - **Solution:** Lazy loading of module components

## Recommendations

### High Priority

1. **Add Frontend Module Enablement Checking**
   - Create utility function: `isModuleEnabled(tenant, moduleName)`
   - Check before rendering module components
   - Show appropriate messages when disabled
   - Example:
   ```typescript
   const isBookerEnabled = isModuleEnabled(tenant, 'booker');
   {isBookerEnabled ? (
     <AppointmentManagementForm ... />
   ) : (
     <Alert>Booker module is not enabled for this tenant</Alert>
   )}
   ```

2. **Include Module Status in Tenant API**
   - Add `enabled_modules: string[]` to tenant response schemas
   - Populate from `tenant.settings.modules`
   - Frontend can use this directly without parsing settings

3. **Create Module Enablement Hook**
   - `useModuleEnabled(moduleName)` hook
   - Automatically checks tenant settings
   - Returns boolean and loading state
   - Example:
   ```typescript
   const { isEnabled, isLoading } = useModuleEnabled('booker');
   ```

### Medium Priority

4. **Auto-Discover Modules**
   - Scan `backend/app/modules/` directory at startup
   - Automatically register routers
   - Reduce manual registration in `main.py`

5. **Lazy Load Module Components**
   - Use React.lazy() for module components
   - Load only when module is enabled
   - Reduce initial bundle size

6. **Module Management UI**
   - Add module enablement toggle in tenant settings
   - Show module status on dashboard
   - Display enabled/disabled modules list

### Low Priority

7. **Module Dependencies**
   - Define module dependencies (e.g., ROPA depends on booker)
   - Enforce dependency checks
   - Prevent disabling required modules

8. **Module Metadata**
   - Store module version, description, requirements
   - Display in UI
   - Check compatibility

9. **Module Cleanup**
   - Optional: Clean up module data when disabled
   - Soft delete vs hard delete option
   - Data retention policies

## Implementation Checklist

When implementing module enablement improvements:

### Backend
- [ ] Add `enabled_modules` to tenant response schemas
- [ ] Create utility to extract enabled modules from settings
- [ ] Update tenant service to include module status
- [ ] Add module enablement validation
- [ ] Consider auto-discovery for module registration

### Frontend
- [ ] Create `isModuleEnabled()` utility function
- [ ] Create `useModuleEnabled()` hook
- [ ] Update `TenantOwnerPage` to check module enablement
- [ ] Update `TenantPublicPage` to check module enablement
- [ ] Add module status display components
- [ ] Implement lazy loading for module components
- [ ] Add module enablement UI in tenant settings

### Testing
- [ ] Test module enablement/disablement
- [ ] Test frontend conditional rendering
- [ ] Test API responses with disabled modules
- [ ] Test data persistence when modules disabled
- [ ] Test module removal process

## Current Module Status

### Booker Module
- **Status:** Enabled by default (backward compatibility)
- **Routes:** `/api/tenants/{tenant_id}/booker/*`
- **Frontend Usage:** `TenantOwnerPage`, `TenantPublicPage`
- **Database Tables:** `appointments`
- **Issues:** Frontend doesn't check enablement

### ROPA Module
- **Status:** Disabled by default
- **Routes:** `/api/tenants/{tenant_id}/ropa/*`
- **Frontend Usage:** None (not yet integrated)
- **Database Tables:** `ropa_repositories`, `ropa_activities`, `ropa_data_elements`, `ropa_dpias`, `ropa_risks`
- **Issues:** No frontend integration yet

## Notes

- Module enablement is stored in `tenant.settings.modules` JSONB field
- Default behavior: `booker` enabled if modules not configured (backward compatibility)
- Routes always registered but protected by `require_module()` dependency
- Frontend currently has no module enablement awareness
- Database tables persist regardless of enablement status

## Future Considerations

1. **Module Marketplace:** Allow installing third-party modules
2. **Module Versioning:** Track module versions and updates
3. **Module Permissions:** Fine-grained permissions per module
4. **Module Analytics:** Track module usage per tenant
5. **Module Templates:** Pre-configured module setups

---

**Last Updated:** 2026-01-03  
**Next Review:** When implementing module enablement improvements



