# Migration Analysis - Single Initial Migration

## Current State

### Tables in Database (14 tables)
1. ✅ `users` - Core user accounts
2. ✅ `tenants` - Organizations/companies
3. ✅ `tenant_users` - User-tenant relationships
4. ❌ `verification_tokens` - **MISSING** (model exists but no migration)
5. ✅ `oauth_accounts` - OAuth authentication
6. ✅ `appointments` - Booker module
7. ✅ `ropa_repositories` - ROPA module
8. ✅ `ropa_activities` - ROPA module
9. ✅ `ropa_data_elements` - ROPA module
10. ✅ `ropa_departments` - ROPA module
11. ✅ `ropa_dpias` - ROPA module
12. ✅ `ropa_locations` - ROPA module (global)
13. ✅ `ropa_risks` - ROPA module
14. ✅ `ropa_systems` - ROPA module
15. ✅ `ai_suggestion_jobs` - ROPA module (was missing, manually created)

### Current Migration Chain (9 migrations)
1. `484a6c8b81ec` - create tenants table
2. `99c6747b5511` - create users table
3. `76d041186dee` - create tenant_users table
4. `5e0c33ea412f` - create appointments table
5. `2928ec4658e4` - add timezone to tenants
6. `7cd90491c305` - change appointment_date to date type
7. `194a74255636` - add_guest_contact_fields_to_appointments
8. `27b4c8bf8175` - add oauth_accounts table
9. `002_initial_ropa_complete` - creates all ROPA tables + ai_suggestion_jobs

## Issues Found

### 1. Missing Table: `verification_tokens`
- **Model exists**: `app/models/verification_token.py`
- **No migration**: No migration file creates this table
- **Impact**: Email verification and password reset won't work

### 2. Fragmented Migrations
- Core tables spread across 4 migrations
- ROPA tables in 1 consolidated migration
- Booker table in separate migration
- OAuth table in separate migration
- Hard to track what's needed for fresh install

### 3. Missing from Consolidated Migration
- `verification_tokens` table
- Could miss other tables in future

## Recommendation: Single Initial Migration

### Benefits
1. **Complete schema**: All tables in one place
2. **No missing tables**: Can verify all models have tables
3. **Easier fresh installs**: One migration to run
4. **Clear dependencies**: All FK relationships visible
5. **Version control**: Single source of truth for schema

### Proposed Structure

**File**: `001_initial_complete_schema.py`

**Tables to include (in dependency order):**
1. **Core Tables** (no dependencies):
   - `users`
   - `tenants`

2. **Core Relationship Tables**:
   - `tenant_users` (depends on users, tenants)
   - `verification_tokens` (depends on users)
   - `oauth_accounts` (depends on users)

3. **Module Tables**:
   - `appointments` (depends on tenants, users)
   
4. **ROPA Lookup Tables**:
   - `ropa_departments` (depends on tenants)
   - `ropa_locations` (global, no dependencies)
   - `ropa_systems` (depends on tenants)

5. **ROPA Core Tables**:
   - `ropa_repositories` (depends on tenants, ropa_departments)
   - `ropa_activities` (depends on ropa_repositories)
   - `ropa_data_elements` (depends on ropa_activities)
   - `ropa_dpias` (depends on ropa_activities)
   - `ropa_risks` (depends on ropa_dpias)

6. **ROPA Support Tables**:
   - `ai_suggestion_jobs` (depends on users, tenants)

### Migration Order
```
Base (empty DB)
  ↓
001_initial_complete_schema
  ↓
(All future migrations for schema changes)
```

## Implementation Plan

1. **Create new migration**: `001_initial_complete_schema.py`
   - Include ALL tables (core + modules)
   - Proper dependency order
   - All indexes and constraints

2. **Archive old migrations**: Move all current migrations to archive
   - Keep for reference but not active

3. **Update down_revision**: Set to `None` (base migration)

4. **Verify completeness**:
   - Check all models have corresponding table creation
   - Verify all foreign keys
   - Test fresh install

5. **Update documentation**: 
   - Update `MIGRATION_CLEANUP.md`
   - Update installation docs

## Verification Checklist

Before creating migration, verify:
- [ ] All models in `app/models/` have table creation
- [ ] All models in `app/modules/*/models/` have table creation
- [ ] All foreign key relationships are correct
- [ ] All indexes are created
- [ ] All unique constraints are created
- [ ] All default values are set
- [ ] All nullable constraints are correct

## Models to Include

### Core Models (`app/models/`)
- ✅ `User` → `users`
- ✅ `Tenant` → `tenants`
- ✅ `TenantUser` → `tenant_users`
- ✅ `VerificationToken` → `verification_tokens` (currently missing!)
- ✅ `OAuthAccount` → `oauth_accounts`

### Booker Module (`app/modules/booker/models/`)
- ✅ `Appointment` → `appointments`

### ROPA Module (`app/modules/ropa/models/`)
- ✅ `Repository` → `ropa_repositories`
- ✅ `Activity` → `ropa_activities`
- ✅ `DataElement` → `ropa_data_elements`
- ✅ `Department` → `ropa_departments`
- ✅ `DPIA` → `ropa_dpias`
- ✅ `Location` → `ropa_locations`
- ✅ `Risk` → `ropa_risks`
- ✅ `System` → `ropa_systems`
- ✅ `AISuggestionJob` → `ai_suggestion_jobs`

**Total: 15 tables**

## Next Steps

1. Review this analysis
2. Create `001_initial_complete_schema.py` with all tables
3. Archive current migrations
4. Test fresh install
5. Update documentation
