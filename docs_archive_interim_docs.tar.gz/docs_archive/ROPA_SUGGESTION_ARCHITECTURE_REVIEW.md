# ROPA Suggestion System - Architecture Review & Best Practices Analysis

**Date:** 2026-01-13  
**Purpose:** Review current implementation against React best practices and identify overengineering  
**Status:** Historical analysis - All identified issues have been fixed (2026-01-17)

---

## Executive Summary

The current implementation uses **manual state management with refs** to handle async operations and polling. While this approach works, it introduces significant complexity with **6+ refs**, **manual synchronization**, and **circular dependencies**. 

**Key Finding:** The implementation is **overengineered** compared to modern React patterns. However, it's solving real problems (stale closures, race conditions) that are well-known in React.

**Recommendation:** The current approach is acceptable but could be simplified. The bugs are NOT due to overengineering - they're due to **circular dependencies** and **timing issues** that can be fixed without major refactoring.

---

## Current Architecture

### State Management

**State Variables:**
- `jobStatuses: Map<string, SuggestionJobStatus>` - Main state
- `activeJobIds: Map<string, string>` - Tracks jobs being polled
- `isRestoring: boolean` - Loading state for restoration
- `jobStatusesVersion: number` - Version counter (unusual pattern)

**Refs (6 total):**
- `jobStatusesRef` - Avoid stale closures in `restoreJobs`
- `activeJobIdsRef` - Avoid stale closures in polling
- `declinedJobIdsRef` - Track declined jobs for filtering
- `clearedFieldsRef` - Track cleared fields to prevent flicker
- `entityIdRef` - Validate entity hasn't changed during async ops
- `pollingIntervalRef` - Store interval ID for cleanup

**Total Complexity:** ~800 lines of code with extensive race condition handling

---

## Comparison with Best Practices

### 1. Polling Pattern

**Current Approach:**
```typescript
// Manual setInterval with refs
pollingIntervalRef.current = setInterval(() => {
  activeJobIdsRef.current.forEach((jobId, fieldName) => {
    pollJobStatus(fieldName, jobId);
  });
}, 2000);
```

**Best Practice (React Query / SWR):**
```typescript
// Automatic polling with built-in state management
const { data } = useQuery({
  queryKey: ['suggestion-job', jobId],
  queryFn: () => getSuggestionJob(jobId),
  refetchInterval: 2000,
  enabled: !!jobId && status === 'pending'
});
```

**Verdict:** ✅ Current approach is acceptable (no React Query in codebase), but manual polling adds complexity.

---

### 2. Stale Closure Handling

**Current Approach:**
```typescript
// Using refs to avoid stale closures
const jobStatusesRef = React.useRef<Map<string, SuggestionJobStatus>>(new Map());

// Update ref whenever state changes
setJobStatuses((prev) => {
  const next = new Map(prev);
  next.set(fieldName, status);
  jobStatusesRef.current = next; // ✅ Update ref
  return next;
});

// Use ref in async operations
const currentJobInState = jobStatusesRef.current.get(fieldName);
```

**Best Practice:**
- ✅ **This is a recognized pattern** for avoiding stale closures in async operations
- ✅ **Refs are the correct solution** when you need current value in callbacks without re-creating them
- ⚠️ **However:** Having 6+ refs suggests the architecture might be too complex

**Verdict:** ✅ Pattern is correct, but complexity is high.

---

### 3. Version Counter Pattern

**Current Approach:**
```typescript
const [jobStatusesVersion, setJobStatusesVersion] = React.useState(0);

// Increment on every state change
setJobStatusesVersion(prev => prev + 1);

// Use in useMemo dependencies
const nameJobStatus = React.useMemo(
  () => suggestionJob.getJobStatus('name'),
  [suggestionJob, suggestionJob.jobStatusesVersion] // ✅ Triggers re-computation
);
```

**Best Practice:**
- ❌ **Unusual pattern** - Typically you'd just depend on the state itself
- ✅ **Works** - But adds unnecessary complexity
- **Better approach:** Depend on `jobStatuses` directly or use a selector function

**Verdict:** ⚠️ Overengineered - version counter is unnecessary.

---

### 4. State Synchronization

**Current Approach:**
```typescript
// Manual synchronization between state and refs
setJobStatuses((prev) => {
  const next = new Map(prev);
  next.set(fieldName, status);
  jobStatusesRef.current = next; // ✅ Manual sync
  return next;
});
```

**Best Practice:**
- ⚠️ **Manual synchronization is error-prone** - Easy to forget to update ref
- ✅ **But necessary** when using refs to avoid stale closures
- **Alternative:** Use a reducer pattern or state management library

**Verdict:** ⚠️ Acceptable but fragile - easy to introduce bugs.

---

### 5. Circular Dependencies

**Current Problem:**
```typescript
// In RepositoryFormDialog.tsx
React.useEffect(() => {
  if (open && repository?.id) {
    restoreJobsRef.current?.();
  }
}, [open, repository?.id, suggestionJob.isRestoring, suggestionJob.jobStatusesVersion]);
// ❌ isRestoring and jobStatusesVersion are OUTPUTS of restoreJobs, not inputs!
```

**Best Practice:**
- ❌ **Circular dependency** - Effect depends on values it modifies
- ✅ **Fix:** Remove `isRestoring` and `jobStatusesVersion` from dependencies
- **Rule:** Only include values that should TRIGGER the effect, not values that are OUTPUTS

**Verdict:** ❌ **This is the root cause of the infinite loop bug!**

---

### 6. Multiple Concurrent Operations

**Current Approach:**
```typescript
// No guard against concurrent restoreJobs calls
const restoreJobs = React.useCallback(async () => {
  setIsRestoring(true);
  // ... fetch and process ...
  setIsRestoring(false);
}, [/* deps */]);
```

**Best Practice:**
- ⚠️ **No guard** - Multiple calls can run concurrently
- ✅ **Should add:** Ref to track if operation is in progress
- **Pattern:**
```typescript
const isRestoringRef = React.useRef(false);
if (isRestoringRef.current) return; // Skip if already running
isRestoringRef.current = true;
try {
  // ... operation ...
} finally {
  isRestoringRef.current = false;
}
```

**Verdict:** ⚠️ Missing guard - allows race conditions.

---

## Well-Known Patterns Being Used

### ✅ Pattern 1: Ref for Stale Closure Avoidance
**Status:** ✅ Correct pattern  
**Reference:** React docs, Dan Abramov's blog  
**Usage:** Used correctly for `jobStatusesRef`, `activeJobIdsRef`

### ✅ Pattern 2: Ref for Mutable Values
**Status:** ✅ Correct pattern  
**Reference:** React docs  
**Usage:** Used correctly for `pollingIntervalRef`, `entityIdRef`

### ⚠️ Pattern 3: Version Counter
**Status:** ⚠️ Unusual but works  
**Reference:** Not a standard pattern  
**Usage:** Could be replaced with direct state dependency

### ❌ Pattern 4: Circular Dependencies
**Status:** ❌ Anti-pattern  
**Reference:** React docs warn against this  
**Usage:** `useEffect` depends on values it modifies

---

## Complexity Analysis

### Current Complexity Score: **7/10** (High)

**Factors:**
- ✅ **6 refs** - High but necessary for stale closure avoidance
- ✅ **Manual polling** - Acceptable (no React Query)
- ⚠️ **Version counter** - Unnecessary complexity
- ❌ **Circular dependencies** - Bug source
- ⚠️ **No concurrency guard** - Allows race conditions
- ✅ **Extensive race condition handling** - Good, but adds complexity

### Ideal Complexity Score: **4/10** (Medium)

**With React Query:**
- ✅ **0 refs** - React Query handles state internally
- ✅ **Automatic polling** - Built-in
- ✅ **No version counter** - Not needed
- ✅ **No circular dependencies** - React Query manages lifecycle
- ✅ **Built-in concurrency handling** - Automatic
- ✅ **Less race condition code** - React Query handles it

**Without React Query (current approach):**
- ✅ **3-4 refs** - Acceptable (reduce from 6)
- ✅ **Manual polling** - Acceptable
- ❌ **Remove version counter** - Use direct state dependency
- ❌ **Fix circular dependencies** - Remove outputs from deps
- ✅ **Add concurrency guard** - Simple fix
- ✅ **Keep race condition handling** - Necessary

---

## Is It Overengineered?

### Verdict: **Partially Overengineered**

**Overengineered Aspects:**
1. ❌ **Version counter** - Unnecessary, adds complexity
2. ❌ **Circular dependencies** - Anti-pattern causing bugs
3. ⚠️ **6 refs** - Could be reduced to 3-4 with better design

**Appropriately Engineered Aspects:**
1. ✅ **Refs for stale closures** - Correct pattern
2. ✅ **Race condition handling** - Necessary for async operations
3. ✅ **Manual polling** - Acceptable without React Query
4. ✅ **State management** - Appropriate for the use case

---

## Root Cause of Bugs

### Bug 1: Infinite Loop
**Root Cause:** Circular dependency in `useEffect`
```typescript
// ❌ WRONG
}, [open, repository?.id, suggestionJob.isRestoring, suggestionJob.jobStatusesVersion]);
// isRestoring and jobStatusesVersion are OUTPUTS, not inputs!

// ✅ CORRECT
}, [open, repository?.id]); // Only inputs that should trigger
```

**Fix Complexity:** ⭐ Easy (1 line change)

---

### Bug 2: All Jobs Filtered Out
**Root Cause:** `clearedFieldsRef` has stale entries OR timing issue
**Possible Causes:**
1. `clearedFieldsRef` not cleared before `restoreJobs` runs
2. Multiple concurrent `restoreJobs` calls interfering
3. Race condition in filtering logic

**Fix Complexity:** ⭐⭐ Medium (requires investigation + guard)

---

### Bug 3: Skeleton on Dismiss
**Root Cause:** `clearJobStatus` triggers `restoreJobs` via `jobStatusesVersion` dependency
**Fix:** Remove `jobStatusesVersion` from dependencies (fixes Bug 1 too)

**Fix Complexity:** ⭐ Easy (same as Bug 1)

---

## Recommendations

### Immediate Fixes (No Refactoring)

1. **Fix Circular Dependency** ⭐ Easy
   - Remove `isRestoring` and `jobStatusesVersion` from `useEffect` dependencies
   - These are OUTPUTS, not inputs

2. **Add Concurrency Guard** ⭐ Easy
   - Add ref to track if `restoreJobs` is running
   - Skip if already in progress

3. **Remove Version Counter** ⭐⭐ Medium
   - Replace with direct state dependency in `useMemo`
   - Or use selector function

### Future Improvements (Optional)

4. **Consider React Query** ⭐⭐⭐ Major
   - Would eliminate most refs
   - Automatic polling and state management
   - Built-in race condition handling
   - **But:** Requires adding dependency and refactoring

5. **Simplify State Management** ⭐⭐⭐ Major
   - Use reducer pattern instead of multiple `useState`
   - Reduces manual synchronization

---

## Conclusion

**Is it overengineered?** 
- **Partially** - The version counter and circular dependencies are overengineered
- **But** - The refs and race condition handling are appropriate for the problem

**Are the bugs due to overengineering?**
- **No** - The bugs are due to:
  1. Circular dependencies (anti-pattern)
  2. Missing concurrency guard (simple fix)
  3. Timing issues (fixable without refactoring)

**Can we fix without major refactoring?**
- **Yes** - All bugs can be fixed with small, targeted changes:
  1. Remove circular dependencies (1 line)
  2. Add concurrency guard (5 lines)
  3. Fix timing issues (investigation + small fix)

**Should we refactor to React Query?**
- **Not necessary** - Current approach works, just needs bug fixes
- **Consider later** - If we add React Query elsewhere, migrate this too

---

## Best Practices Alignment

| Pattern | Current | Best Practice | Status |
|---------|---------|---------------|--------|
| Stale closure handling | Refs | Refs | ✅ Correct |
| Polling | Manual setInterval | React Query (or manual) | ✅ Acceptable |
| State management | Multiple useState | useState or reducer | ✅ Acceptable |
| Version counter | Custom pattern | Direct dependency | ⚠️ Unusual |
| Circular dependencies | Present | Avoid | ❌ Anti-pattern |
| Concurrency guard | Missing | Should have | ⚠️ Missing |
| Race condition handling | Extensive | Necessary | ✅ Good |

**Overall:** The implementation follows most best practices, but has **2 anti-patterns** (circular dependencies, version counter) that are causing bugs.

---

**Last Updated:** 2026-01-13
