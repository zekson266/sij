# Select/Multiselect Field Suggestion Support - Analysis

**Date**: 2026-01-17  
**Purpose**: Analyze current system to understand how to add select/multiselect field suggestions without breaking existing functionality  
**Status**: Analysis Complete - Ready for Implementation

---

## Current System Understanding

### ✅ What Already Works

1. **Backend Support**:
   - API accepts `field_options` parameter in request
   - Backend includes `field_options` in OpenAI prompt (line 196-197 in `openai_service.py`)
   - AI receives available options but is NOT explicitly constrained to only suggest from them

2. **Frontend Infrastructure**:
   - `useSuggestionJob.createJob()` accepts `fieldOptions?: string[]` parameter
   - `useSuggestionJob.suggestAll()` accepts `fieldOptionsMap?: Record<string, string[]>` parameter
   - API request includes `field_options` in payload

3. **Form Patterns (CRITICAL - Must Preserve)**:
   - **Restoration**: Uses ref pattern to avoid unnecessary re-triggers
     ```typescript
     const restoreJobsRef = React.useRef<(() => Promise<void>) | null>(null);
     restoreJobsRef.current = suggestionJob.restoreJobs;
     
     React.useEffect(() => {
       if (open && entity?.id && restoreJobsRef.current) {
         const timer = setTimeout(() => {
           restoreJobsRef.current?.();
         }, 100);
         return () => clearTimeout(timer);
       }
     }, [open, entity?.id]); // ✅ Only primitives in deps
     ```
   - **Form Reset**: Uses `[entity?.id, reset]` NOT `[entity, reset]`
   - **Button State**: `disabled={isSubmitting}` only (no `isDirty`)
   - **Reset Options**: `keepDefaultValues: false` in all reset calls
   - **No Reset on Close**: Preserve state for restoration

### ❌ What's Missing

1. **No Select Fields Use Suggestions**:
   - Fields like `repository_type`, `status`, `storage_type`, `environment`, etc. use plain `FormSelect`
   - No `FormFieldWithSuggestion` wrapper for select fields

2. **handleSuggestField Doesn't Pass fieldOptions**:
   - Current signature: `handleSuggestField(fieldName, fieldType, fieldLabel, currentValue, formData)`
   - Missing: `fieldOptions` parameter
   - Even if select fields used `FormFieldWithSuggestion`, options wouldn't be sent to AI

3. **No Validation on Accept**:
   - When accepting suggestions, no check that value matches predefined options
   - Form validation would catch invalid values, but AI could suggest values outside options

---

## Implementation Plan (When Ready)

### Step 1: Update `handleSuggestField` Function

**Location**: `frontend/src/modules/ropa/components/RepositoryFormDialog.tsx` (and other form dialogs)

**Current**:
```typescript
const handleSuggestField = React.useCallback(async (
  fieldName: string,
  fieldType: string,
  fieldLabel: string,
  currentValue: string,
  formData: Record<string, any>
) => {
  // ...
  await suggestionJob.createJob(
    fieldName,
    fieldType,
    fieldLabel,
    currentValue,
    formData
    // ❌ Missing fieldOptions
  );
}, [suggestionJob]);
```

**Updated**:
```typescript
const handleSuggestField = React.useCallback(async (
  fieldName: string,
  fieldType: string,
  fieldLabel: string,
  currentValue: string,
  formData: Record<string, any>,
  fieldOptions?: string[] // ✅ Add optional parameter
) => {
  // ...
  await suggestionJob.createJob(
    fieldName,
    fieldType,
    fieldLabel,
    currentValue,
    formData,
    fieldOptions // ✅ Pass to createJob
  );
}, [suggestionJob]);
```

**Impact**: 
- ✅ Backward compatible (optional parameter)
- ✅ Existing text/textarea/multiselect fields unaffected
- ✅ No breaking changes

### Step 2: Update Select Fields to Use FormFieldWithSuggestion

**Location**: `frontend/src/modules/ropa/components/RepositoryFormDialog.tsx`

**Example - repository_type field**:

**Current**:
```typescript
<FormSelect
  name="repository_type"
  control={control}
  label="Repository Type"
  options={REPOSITORY_TYPE_OPTIONS}
/>
```

**Updated**:
```typescript
{isEditMode && repository?.id ? (
  <FormFieldWithSuggestion
    name="repository_type"
    control={control}
    label="Repository Type"
    fieldType="select"
    selectOptions={REPOSITORY_TYPE_OPTIONS}
    jobStatus={repositoryTypeJobStatus}
    isSuggesting={isFieldSuggesting('repository_type')}
    isRestoring={suggestionJob.isRestoring}
    onSuggest={async () => {
      const formData = watch();
      await handleSuggestField(
        'repository_type',
        'select',
        'Repository Type',
        formData.repository_type || '',
        formData,
        REPOSITORY_TYPE_OPTIONS.map(opt => opt.value) // ✅ Pass options
      );
    }}
    onAccept={(suggestion) => {
      if (Array.isArray(suggestion)) {
        // Accept All - take first suggestion for single select
        setValue('repository_type', suggestion[0], { shouldValidate: true });
      } else if (typeof suggestion === 'string') {
        // Single suggestion
        setValue('repository_type', suggestion, { shouldValidate: true });
      }
    }}
    onDismiss={() => {
      suggestionJob.clearJobStatus('repository_type');
    }}
  />
) : (
  <FormSelect
    name="repository_type"
    control={control}
    label="Repository Type"
    options={REPOSITORY_TYPE_OPTIONS}
  />
)}
```

**Impact**:
- ✅ Follows existing pattern (edit mode only)
- ✅ Uses same restoration logic (no changes needed)
- ✅ Uses same form reset pattern (no changes needed)
- ✅ Preserves all existing functionality

### Step 3: Update Backend Prompt (Optional Enhancement)

**Location**: `backend/app/services/openai_service.py`

**Current** (line 196-197):
```python
if field_options:
    prompt_parts.append(f"Available options: {', '.join(field_options)}")
```

**Enhanced** (optional):
```python
if field_options:
    prompt_parts.append(f"Available options: {', '.join(field_options)}")
    prompt_parts.append(
        "\nCRITICAL: You MUST only suggest values from the available options above. "
        "Do not suggest values that are not in the list."
    )
```

**Impact**:
- ✅ Better AI compliance with predefined values
- ✅ Reduces invalid suggestions
- ✅ Still backward compatible

### Step 4: Add Validation on Accept (Optional Enhancement)

**Location**: `frontend/src/modules/ropa/components/FormFieldWithSuggestion.tsx` or form dialogs

**Option A - In onAccept handler**:
```typescript
onAccept={(suggestion) => {
  const value = Array.isArray(suggestion) ? suggestion[0] : suggestion;
  
  // ✅ Validate against options
  const isValid = REPOSITORY_TYPE_OPTIONS.some(opt => opt.value === value);
  if (!isValid) {
    showError(`Invalid suggestion: "${value}" is not a valid option`);
    return;
  }
  
  setValue('repository_type', value, { shouldValidate: true });
}}
```

**Option B - In FormFieldWithSuggestion component**:
- Add validation prop
- Validate before calling `onAccept`

**Impact**:
- ✅ Prevents invalid values from being set
- ✅ Better user experience
- ✅ Optional - form validation would catch it anyway

---

## Critical Patterns to Preserve

### 1. Restoration Logic (MUST NOT BREAK)

**Current Pattern**:
```typescript
const restoreJobsRef = React.useRef<(() => Promise<void>) | null>(null);
restoreJobsRef.current = suggestionJob.restoreJobs;

React.useEffect(() => {
  if (open && entity?.id && restoreJobsRef.current) {
    const timer = setTimeout(() => {
      restoreJobsRef.current?.();
    }, 100);
    return () => clearTimeout(timer);
  }
}, [open, entity?.id]); // ✅ Only primitives
```

**Why Critical**:
- Prevents unnecessary re-triggers when `suggestionJob` object reference changes
- Ensures restoration only happens when dialog opens or entity changes
- Prevents flickering/blinking UI

**Impact of Changes**:
- ✅ No impact - restoration is based on `entityId`, not field type
- ✅ Select fields will restore just like text fields

### 2. Form Reset Pattern (MUST NOT BREAK)

**Current Pattern**:
```typescript
React.useEffect(() => {
  if (entity) {
    reset({
      repository_type: entity.repository_type,
      // ... all fields
    }, { keepDefaultValues: false });
  }
}, [entity?.id, reset]); // ✅ Use entity?.id, not entity
```

**Why Critical**:
- Prevents form from resetting while user is typing
- Only resets when switching to different entity

**Impact of Changes**:
- ✅ No impact - reset pattern is independent of field type
- ✅ Select fields reset just like text fields

### 3. State Management (MUST NOT BREAK)

**Current Pattern**:
- Uses `jobStatusesVersion` for triggering re-renders
- Uses refs to avoid stale closures
- Uses `useMemo` for job status derivation

**Impact of Changes**:
- ✅ No impact - state management is field-type agnostic
- ✅ Select fields use same state management as text fields

### 4. Button Disabled State (MUST NOT BREAK)

**Current Pattern**:
```typescript
disabled={isSubmitting} // ✅ Only isSubmitting, no isDirty
```

**Impact of Changes**:
- ✅ No impact - button state is independent of field type

---

## Testing Checklist

When implementing, verify:

- [ ] **Restoration**: Select field suggestions restore when dialog reopens
- [ ] **Form Reset**: Select field doesn't reset while typing
- [ ] **Entity Switch**: Form resets correctly when switching entities
- [ ] **Suggest Button**: Creates job and shows loading state
- [ ] **Polling**: Job status updates correctly
- [ ] **Accept**: Sets value correctly (validates against options)
- [ ] **Dismiss**: Clears suggestion correctly
- [ ] **Suggest All**: Includes select fields in batch suggestion
- [ ] **Existing Fields**: Text/textarea/multiselect fields still work
- [ ] **No Flickering**: No UI flickering when creating/restoring jobs
- [ ] **No Race Conditions**: No state overwrites when switching entities quickly

---

## Files to Modify

1. **Frontend**:
   - `frontend/src/modules/ropa/components/RepositoryFormDialog.tsx`
     - Update `handleSuggestField` signature
     - Update select fields to use `FormFieldWithSuggestion`
     - Add job status memoization for select fields
   - `frontend/src/modules/ropa/components/ActivityFormDialog.tsx` (if has select fields)
   - `frontend/src/modules/ropa/components/DataElementFormDialog.tsx` (if has select fields)
   - `frontend/src/modules/ropa/components/DPIAFormDialog.tsx` (if has select fields)
   - `frontend/src/modules/ropa/components/RiskFormDialog.tsx` (if has select fields)

2. **Backend** (Optional Enhancement):
   - `backend/app/services/openai_service.py`
     - Enhance prompt to explicitly constrain suggestions to options

3. **Documentation** (After Implementation):
   - `ROPA_AI_SUGGESTIONS.md` - Document select field support
   - `frontend/COMPONENT_PATTERNS.md` - Update AI Suggestion Field Pattern

---

## Risk Assessment

### Low Risk ✅
- Adding optional parameter to `handleSuggestField` (backward compatible)
- Updating select fields to use `FormFieldWithSuggestion` (follows existing pattern)
- Restoration logic (field-type agnostic)
- Form reset logic (field-type agnostic)

### Medium Risk ⚠️
- Ensuring AI only suggests valid options (backend prompt enhancement)
- Validation on accept (optional, but good UX)

### No Risk ✅
- Existing text/textarea/multiselect fields (no changes to them)
- State management (field-type agnostic)
- Polling logic (field-type agnostic)

---

## Summary

**Current Status**: Infrastructure exists, but not implemented for select/multiselect fields.

**Implementation Complexity**: Low - mostly following existing patterns.

**Breaking Changes**: None - all changes are backward compatible.

**Critical Patterns**: All preserved - restoration, form reset, state management unchanged.

**Ready for Implementation**: ✅ Yes, after user approval.

---

**Last Updated**: 2026-01-17
