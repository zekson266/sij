# Install Script Verification - Cookie Authentication

## ✅ Status: READY FOR FRESH INSTALLATION

The install script (`install.sh`) has been updated and will automatically configure cookie-based authentication from scratch.

---

## What the Script Does Automatically

### 1. Cookie Configuration (NEW)
- ✅ Adds cookie settings to `.env` template
- ✅ Automatically sets `COOKIE_DOMAIN=.onebrat.xyz` for production domains
- ✅ Sets `COOKIE_SECURE=1` for production (HTTPS)
- ✅ Sets `COOKIE_SECURE=0` for localhost (HTTP allowed)
- ✅ Sets `COOKIE_SAMESITE=lax` for CSRF protection

### 2. Dependencies
- ✅ `slowapi` is in `backend/requirements.txt`
- ✅ Dockerfile automatically installs all requirements during build
- ✅ No manual dependency installation needed

### 3. Existing Features (Still Work)
- ✅ SSL certificate generation
- ✅ Secret key generation
- ✅ Database setup
- ✅ Environment configuration

---

## Fresh Installation Process

### Step 1: Run Install Script
```bash
DOMAIN_NAME=onebrat.xyz ./install.sh
```

**What happens:**
1. Creates `.env` with cookie configuration
2. Sets `COOKIE_DOMAIN=.onebrat.xyz` automatically
3. Sets `COOKIE_SECURE=1` for production
4. Generates SSL certificates
5. Sets up database

### Step 2: Start Services
```bash
docker compose up -d
```

**What happens:**
1. Backend container builds and installs `slowapi` automatically
2. All dependencies from `requirements.txt` are installed
3. Services start with correct configuration

### Step 3: Run Migrations
```bash
docker compose exec backend alembic upgrade head
```

### Step 4: Build Frontend
```bash
docker compose up frontend-build
```

---

## Verification After Installation

### Check Cookie Configuration
```bash
grep -E "^(COOKIE_DOMAIN|COOKIE_SECURE|COOKIE_SAMESITE)=" .env
```

**Expected output for production:**
```
COOKIE_DOMAIN=.onebrat.xyz
COOKIE_SECURE=1
COOKIE_SAMESITE=lax
```

### Check Rate Limiting Installed
```bash
docker compose exec backend pip list | grep slowapi
```

**Expected output:**
```
slowapi    0.1.9
```

### Check Backend Starts
```bash
docker compose logs backend | grep -i "rate limiting"
```

**Expected output:**
```
Rate limiting configured
```

---

## Configuration Logic

### Production Domain (e.g., `onebrat.xyz`)
- `COOKIE_DOMAIN=.onebrat.xyz` (with leading dot for subdomain sharing)
- `COOKIE_SECURE=1` (HTTPS only)
- `COOKIE_SAMESITE=lax` (CSRF protection)

### Localhost Development
- `COOKIE_DOMAIN=` (empty, works on localhost only)
- `COOKIE_SECURE=0` (HTTP allowed)
- `COOKIE_SAMESITE=lax` (CSRF protection)

---

## What's Automatic

✅ **Cookie domain** - Set automatically based on `DOMAIN_NAME`  
✅ **Cookie secure flag** - Set automatically (1 for production, 0 for localhost)  
✅ **Dependencies** - Installed automatically during Docker build  
✅ **Rate limiting** - Configured automatically (slowapi in requirements.txt)  
✅ **All existing features** - Still work as before  

---

## Manual Steps Still Required

1. **Run install script** - `./install.sh`
2. **Start services** - `docker compose up -d`
3. **Run migrations** - `docker compose exec backend alembic upgrade head`
4. **Build frontend** - `docker compose up frontend-build`

**Note:** These are standard steps, not cookie-specific.

---

## Testing After Fresh Install

1. Login at `https://onebrat.xyz/login`
2. Check cookies in DevTools → Application → Cookies
3. Verify cookie has:
   - Domain: `.onebrat.xyz`
   - HttpOnly: ✅
   - Secure: ✅
   - SameSite: `Lax`
4. Navigate to subdomain: `https://[tenant-slug].onebrat.xyz`
5. Verify user is recognized as logged in

---

## Summary

✅ **Install script is complete and ready**  
✅ **Cookie configuration is automatic**  
✅ **Dependencies are auto-installed**  
✅ **Works for both production and localhost**  
✅ **No manual cookie configuration needed**  

**You can run `./install.sh` from scratch and everything will be configured automatically!**

