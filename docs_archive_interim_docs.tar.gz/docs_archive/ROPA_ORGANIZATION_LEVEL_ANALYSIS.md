# ROPA Tree - Organization Level Analysis

**Date:** 2026-01-03  
**Question:** Can we create another level in the tree to show "Organization" with a panel containing ROPA Dashboard, Import/Export?  
**Answer:** ✅ **YES, this is feasible and well-aligned with the existing architecture**

---

## Executive Summary

**Feasibility:** ✅ **YES** - The Tenant model already exists and represents an organization. Adding it as the root level of the tree is architecturally sound and would provide a better user experience.

**Current Structure:**
```
Repository → Activity → Data Elements / DPIAs → Risks
```

**Proposed Structure:**
```
Organization (Tenant) → Repository → Activity → Data Elements / DPIAs → Risks
```

**Organization Panel Contents:**
- ROPA Dashboard (statistics, overview, compliance status)
- Import/Export functionality
- Organization-level settings/configuration

---

## 1. Architectural Feasibility

### ✅ Data Model - Already Exists

The `Tenant` model already represents an organization:

```python
# backend/app/models/tenant.py
class Tenant(Base):
    id: UUID
    name: str  # Organization name
    slug: str
    email: str
    # ... other fields
```

**Key Points:**
- ✅ Tenant model already exists
- ✅ All ROPA entities are tenant-scoped (Repository has `tenant_id`)
- ✅ No database changes needed
- ✅ Current ROPA page already uses tenant data via `useTenantData` hook

### Current ROPA Data Flow

```typescript
// frontend/src/modules/ropa/pages/ROPAPage.tsx
const { tenant, canEdit, isLoading, error } = useTenantData(id);
// tenant.id is used to fetch repositories
const repositories = await listRepositories(id); // id = tenant.id
```

**Conclusion:** The organization (tenant) is already the logical root of all ROPA data. Making it visible in the tree is a natural extension.

---

## 2. Proposed Tree Structure

### Visual Representation

```
📁 Organization: Acme Corp
  ├── 📦 Repository: Customer Database
  │   ├── 📋 Activity: Customer Onboarding
  │   │   ├── 📊 Data Element: Email Address
  │   │   ├── 📊 Data Element: Phone Number
  │   │   └── 📝 DPIA: Customer Data Processing
  │   │       └── ⚠️ Risk: Data Breach Risk
  │   └── 📋 Activity: Order Processing
  └── 📦 Repository: Analytics Platform
      └── 📋 Activity: User Analytics
```

### Tree Item Types

```typescript
interface ROPATreeItem {
  id: string;
  label: string;
  children?: ROPATreeItem[];
  type: 'organization' | 'repository' | 'activity' | 'data_element' | 'dpia' | 'risk' | 'add_action';
  data?: Tenant | Repository | Activity | DataElement | DPIA | Risk;
  // ... other fields
}
```

**New Type:** `'organization'` - represents the Tenant/Organization root node

---

## 3. Organization Panel Design

### Panel Structure

When the Organization node is selected, show a special dashboard panel instead of entity details:

```
┌─────────────────────────────────────────┐
│  Organization: Acme Corp                │
│  ─────────────────────────────────────  │
│                                         │
│  📊 ROPA Dashboard                      │
│  ─────────────────────────────────────  │
│  • Total Repositories: 5               │
│  • Total Activities: 12                │
│  • Total Data Elements: 45             │
│  • Total DPIAs: 8                      │
│  • Total Risks: 15                      │
│  • Compliance Status: ✅ Compliant      │
│                                         │
│  📥 Import / Export                    │
│  ─────────────────────────────────────  │
│  [Export ROPA Data] [Import ROPA Data]  │
│                                         │
│  ⚙️ Organization Settings               │
│  ─────────────────────────────────────  │
│  • Timezone: America/New_York           │
│  • Subscription: Pro                    │
│  [View Settings]                        │
└─────────────────────────────────────────┘
```

### Panel Components

#### 3.1 ROPA Dashboard Section

**Statistics Cards:**
- Total Repositories
- Total Activities
- Total Data Elements
- Total DPIAs
- Total Risks
- Compliance Status (calculated based on completeness)

**Visual Elements:**
- Summary cards (similar to TenantOwnerPage)
- Charts/graphs (optional):
  - Repositories by type
  - Activities by status
  - DPIAs by status
  - Risks by severity

**Data Source:**
- Already calculated in `TenantOwnerPage.tsx` (lines 41-113)
- Can reuse `fetchROPAStats` logic
- Or create dedicated API endpoint: `GET /api/tenants/{id}/ropa/dashboard`

#### 3.2 Import/Export Section

**Export Functionality:**
- Export all ROPA data for the organization
- Formats: JSON, CSV, Excel, PDF
- Include all entities: Repositories, Activities, Data Elements, DPIAs, Risks
- Include relationships and metadata

**Import Functionality:**
- Import ROPA data from file
- Validate data structure
- Handle duplicates (update vs. create)
- Preview before import
- Show import results/errors

**API Endpoints Needed:**
```
POST /api/tenants/{id}/ropa/export
  - Query params: format (json|csv|xlsx|pdf)
  - Returns: File download

POST /api/tenants/{id}/ropa/import
  - Body: File upload (multipart/form-data)
  - Returns: Import results with success/error counts
```

**UI Components:**
- Export button with format selector
- Import button with file picker
- Progress indicator for large exports/imports
- Results dialog showing import/export status

#### 3.3 Organization Settings Section

**Display:**
- Organization name
- Timezone
- Subscription tier
- Contact information
- Link to full settings page

**Actions:**
- Quick link to organization settings
- Module enablement status
- ROPA-specific settings

---

## 4. Implementation Approach

### 4.1 Tree Structure Changes

**Current Tree Building:**
```typescript
// Current: Start with repositories
const repositories = await listRepositories(id);
const items: ROPATreeItem[] = repositories.map(repo => {
  // Build tree from repository down
});
```

**New Tree Building:**
```typescript
// New: Start with organization
const organizationItem: ROPATreeItem = {
  id: `organization-${tenant.id}`,
  label: tenant.name,
  type: 'organization',
  data: tenant,
  children: repositories.map(repo => {
    // Build tree from repository down (same as before)
  })
};

const treeItems = [organizationItem];
```

**Key Changes:**
1. Wrap existing tree in organization root
2. Add "Add Repository" as child of organization
3. Handle organization click to show dashboard panel

### 4.2 Panel Component

**New Component:** `ROPAOrganizationPanel.tsx`

```typescript
interface ROPAOrganizationPanelProps {
  tenant: Tenant;
  onExport: (format: string) => void;
  onImport: (file: File) => void;
}

export default function ROPAOrganizationPanel({
  tenant,
  onExport,
  onImport,
}: ROPAOrganizationPanelProps) {
  // Dashboard statistics
  const [stats, setStats] = React.useState<ROPAStats | null>(null);
  
  // Import/Export state
  const [isExporting, setIsExporting] = React.useState(false);
  const [isImporting, setIsImporting] = React.useState(false);
  
  return (
    <Box>
      {/* Dashboard Section */}
      <ROPADashboard stats={stats} />
      
      {/* Import/Export Section */}
      <ROPAImportExport
        onExport={onExport}
        onImport={onImport}
        isExporting={isExporting}
        isImporting={isImporting}
      />
      
      {/* Settings Section */}
      <ROPAOrganizationSettings tenant={tenant} />
    </Box>
  );
}
```

### 4.3 ROPAPage Updates

**Selection Handling:**
```typescript
const handleItemClick = (_event: React.SyntheticEvent, itemId: string) => {
  const item = findItemInTree(treeItems, itemId);
  if (!item) return;

  // Handle organization selection
  if (item.type === 'organization') {
    setSelectedItem(item);
    // Show organization panel (dashboard)
    return;
  }

  // Handle "Add New..." actions
  if (item.type === 'add_action') {
    // ... existing logic
  }

  // Normal item selection
  setSelectedItem(item);
};
```

**Panel Rendering:**
```typescript
{selectedItem && selectedItem.type === 'organization' ? (
  <ROPAOrganizationPanel
    tenant={selectedItem.data as Tenant}
    onExport={handleExport}
    onImport={handleImport}
  />
) : selectedItem && selectedItem.type !== 'add_action' ? (
  <ROPADetailsPanel
    itemType={selectedItem.type}
    data={selectedItem.data}
  />
) : (
  // Empty state
)}
```

### 4.4 Backend API Endpoints

**New Endpoints:**

```python
# backend/app/modules/ropa/routers.py

@router.get("/tenants/{tenant_id}/ropa/dashboard")
def get_ropa_dashboard(
    tenant_id: UUID,
    tenant: Tenant = Depends(require_module("ropa")),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get ROPA dashboard statistics for organization."""
    # Calculate statistics
    # Return summary data

@router.post("/tenants/{tenant_id}/ropa/export")
def export_ropa_data(
    tenant_id: UUID,
    format: str = Query("json"),  # json, csv, xlsx, pdf
    tenant: Tenant = Depends(require_module("ropa")),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Export all ROPA data for organization."""
    # Fetch all ROPA entities
    # Format according to requested format
    # Return file download

@router.post("/tenants/{tenant_id}/ropa/import")
def import_ropa_data(
    tenant_id: UUID,
    file: UploadFile,
    tenant: Tenant = Depends(require_module("ropa")),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Import ROPA data from file."""
    # Parse file
    # Validate data
    # Create/update entities
    # Return import results
```

---

## 5. Benefits

### 5.1 User Experience

✅ **Clear Hierarchy** - Organization is the logical root  
✅ **Better Navigation** - Always know which organization you're viewing  
✅ **Dashboard Access** - Quick access to overview and statistics  
✅ **Bulk Operations** - Import/Export at organization level makes sense  

### 5.2 Data Management

✅ **Bulk Export** - Export entire ROPA structure for backup/compliance  
✅ **Data Migration** - Import ROPA data when setting up new tenant  
✅ **Compliance Reporting** - Export for regulatory submissions  
✅ **Backup/Restore** - Full organization-level backup capability  

### 5.3 Architecture

✅ **No Database Changes** - Tenant model already exists  
✅ **Consistent Pattern** - Follows existing tree structure  
✅ **Reusable Components** - Dashboard stats already calculated  
✅ **Scalable** - Easy to add more organization-level features  

---

## 6. Considerations

### 6.1 Tree Expansion

**Question:** Should organization node be expanded by default?

**Recommendation:** 
- ✅ Yes, expand by default (it's the root)
- Auto-expand organization when tree loads
- User can still collapse if needed

### 6.2 Panel Layout

**Question:** How much space for dashboard vs. import/export?

**Recommendation:**
- Dashboard: Primary focus (60-70% of panel)
- Import/Export: Secondary actions (30-40% of panel)
- Use tabs or sections for organization

### 6.3 Import/Export Format

**Question:** Which formats to support?

**Recommendation:**
- **JSON** - Primary format (structured, preserves relationships)
- **CSV** - For spreadsheet users (flattened structure)
- **Excel** - For business users (multiple sheets)
- **PDF** - For compliance reports (read-only, formatted)

### 6.4 Performance

**Considerations:**
- Large organizations may have many repositories
- Export could be slow for large datasets
- Consider pagination or async export
- Show progress indicator for exports

### 6.5 Permissions

**Question:** Who can import/export?

**Recommendation:**
- Export: All users with ROPA access
- Import: Only owners/admins (data modification)
- Dashboard: All users with ROPA access

---

## 7. Implementation Checklist

### Phase 1: Tree Structure
- [ ] Add `'organization'` to `ROPATreeItem` type
- [ ] Update `fetchROPAData` to wrap tree in organization root
- [ ] Add organization icon to `getIconForType`
- [ ] Update tree building logic
- [ ] Handle organization node click

### Phase 2: Organization Panel
- [ ] Create `ROPAOrganizationPanel` component
- [ ] Create `ROPADashboard` component (reuse stats logic)
- [ ] Create `ROPAImportExport` component
- [ ] Create `ROPAOrganizationSettings` component
- [ ] Update `ROPAPage` to render organization panel

### Phase 3: Backend API
- [ ] Create `GET /ropa/dashboard` endpoint
- [ ] Create `POST /ropa/export` endpoint
- [ ] Create `POST /ropa/import` endpoint
- [ ] Add validation for import data
- [ ] Add error handling

### Phase 4: Import/Export Logic
- [ ] Implement JSON export/import
- [ ] Implement CSV export/import
- [ ] Implement Excel export/import (optional)
- [ ] Implement PDF export (optional)
- [ ] Add progress indicators
- [ ] Add import preview/validation

### Phase 5: Testing
- [ ] Test tree structure with organization root
- [ ] Test dashboard statistics
- [ ] Test export functionality
- [ ] Test import functionality
- [ ] Test permissions
- [ ] Test with large datasets

---

## 8. Example Code Structure

### Tree Item with Organization

```typescript
const buildTreeWithOrganization = async (tenant: Tenant): Promise<ROPATreeItem[]> => {
  // Fetch repositories (existing logic)
  const repositories = await listRepositories(tenant.id);
  
  // Build repository tree (existing logic)
  const repositoryItems = await Promise.all(
    repositories.map(async (repo) => {
      // ... existing tree building
    })
  );
  
  // Wrap in organization root
  const organizationItem: ROPATreeItem = {
    id: `organization-${tenant.id}`,
    label: tenant.name,
    type: 'organization',
    data: tenant,
    children: [
      ...repositoryItems,
      {
        id: 'add-repository',
        label: 'Add Repository',
        type: 'add_action',
        addActionType: 'repository',
      },
    ],
  };
  
  return [organizationItem];
};
```

### Organization Panel Component

```typescript
export default function ROPAOrganizationPanel({ tenant }: Props) {
  const [stats, setStats] = React.useState<ROPAStats | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  
  React.useEffect(() => {
    fetchDashboardStats(tenant.id).then(setStats).finally(() => setIsLoading(false));
  }, [tenant.id]);
  
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        {tenant.name}
      </Typography>
      
      <Divider sx={{ my: 3 }} />
      
      {/* Dashboard */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          ROPA Dashboard
        </Typography>
        {isLoading ? (
          <CircularProgress />
        ) : (
          <ROPAStatsGrid stats={stats} />
        )}
      </Box>
      
      {/* Import/Export */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Import / Export
        </Typography>
        <Stack direction="row" spacing={2}>
          <Button variant="contained" onClick={handleExport}>
            Export ROPA Data
          </Button>
          <Button variant="outlined" component="label">
            Import ROPA Data
            <input type="file" hidden onChange={handleImport} />
          </Button>
        </Stack>
      </Box>
      
      {/* Settings */}
      <Box>
        <Typography variant="h6" gutterBottom>
          Organization Settings
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Timezone: {tenant.timezone}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Subscription: {tenant.subscription_tier}
        </Typography>
      </Box>
    </Box>
  );
}
```

---

## 9. Conclusion

✅ **Feasibility:** YES - This is a natural extension of the existing architecture

✅ **Benefits:**
- Better user experience with clear hierarchy
- Dashboard access for quick overview
- Import/Export for data management
- No database changes needed

✅ **Implementation:**
- Straightforward tree structure change
- Reuse existing statistics logic
- Add new panel component
- Add backend endpoints for import/export

✅ **Recommendation:** Proceed with implementation. This enhancement would significantly improve the ROPA module's usability and functionality.

---

## 10. Next Steps

1. **Review this analysis** - Confirm approach and requirements
2. **Design panel UI** - Create mockups for dashboard and import/export
3. **Plan implementation** - Break down into phases
4. **Implement tree changes** - Add organization root level
5. **Implement panel** - Create organization panel component
6. **Implement backend** - Add dashboard and import/export endpoints
7. **Test thoroughly** - Especially import/export with various data sizes

---

**Status:** ✅ Ready for implementation  
**Complexity:** Medium  
**Estimated Effort:** 2-3 days for full implementation  
**Dependencies:** None (all required models and data exist)
