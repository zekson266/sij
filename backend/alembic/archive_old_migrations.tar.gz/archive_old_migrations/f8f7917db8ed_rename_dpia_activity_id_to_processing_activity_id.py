"""rename_dpia_activity_id_to_processing_activity_id

Revision ID: f8f7917db8ed
Revises: 612a9d01e9a1
Create Date: 2026-01-20 02:20:03.004714

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'f8f7917db8ed'
down_revision: Union[str, None] = '612a9d01e9a1'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Rename activity_id to processing_activity_id in ropa_dpias table
    op.alter_column('ropa_dpias', 'activity_id', new_column_name='processing_activity_id')


def downgrade() -> None:
    # Rename processing_activity_id back to activity_id
    op.alter_column('ropa_dpias', 'processing_activity_id', new_column_name='activity_id')

