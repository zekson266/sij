"""add comprehensive fields to activity table

Revision ID: a1b2c3d4e5f8
Revises: a1b2c3d4e5f7
Create Date: 2026-01-03 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f8'
down_revision: Union[str, None] = 'a1b2c3d4e5f7'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ========== Business Context ==========
    op.add_column('ropa_activities', sa.Column('business_function', sa.String(length=255), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_owner', sa.String(length=255), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_status', sa.String(length=50), nullable=True))
    op.create_index(op.f('ix_ropa_activities_processing_status'), 'ropa_activities', ['processing_status'], unique=False)
    
    # ========== Processing Details ==========
    op.add_column('ropa_activities', sa.Column('processing_operations', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_systems', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_locations', sa.Text(), nullable=True))
    
    # ========== Automation and Profiling ==========
    op.add_column('ropa_activities', sa.Column('degree_of_automation', sa.String(length=50), nullable=True))
    op.add_column('ropa_activities', sa.Column('use_of_profiling', sa.Boolean(), nullable=False, server_default='false'))
    
    # ========== Data Storage and Format ==========
    op.add_column('ropa_activities', sa.Column('storage_system', sa.String(length=255), nullable=True))
    op.add_column('ropa_activities', sa.Column('data_format', sa.String(length=100), nullable=True))
    
    # ========== Data Retention and Deletion ==========
    op.add_column('ropa_activities', sa.Column('retention_period', sa.String(length=100), nullable=True))
    op.add_column('ropa_activities', sa.Column('deletion_method', sa.String(length=100), nullable=True))
    
    # ========== Access and Recipients ==========
    op.add_column('ropa_activities', sa.Column('internal_access_roles', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_activities', sa.Column('external_recipients', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_activities', sa.Column('international_transfer', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index(op.f('ix_ropa_activities_international_transfer'), 'ropa_activities', ['international_transfer'], unique=False)


def downgrade() -> None:
    # Drop indexes
    op.drop_index(op.f('ix_ropa_activities_international_transfer'), table_name='ropa_activities')
    op.drop_index(op.f('ix_ropa_activities_processing_status'), table_name='ropa_activities')
    
    # Drop columns
    op.drop_column('ropa_activities', 'international_transfer')
    op.drop_column('ropa_activities', 'external_recipients')
    op.drop_column('ropa_activities', 'internal_access_roles')
    op.drop_column('ropa_activities', 'deletion_method')
    op.drop_column('ropa_activities', 'retention_period')
    op.drop_column('ropa_activities', 'data_format')
    op.drop_column('ropa_activities', 'storage_system')
    op.drop_column('ropa_activities', 'use_of_profiling')
    op.drop_column('ropa_activities', 'degree_of_automation')
    op.drop_column('ropa_activities', 'processing_locations')
    op.drop_column('ropa_activities', 'processing_systems')
    op.drop_column('ropa_activities', 'processing_operations')
    op.drop_column('ropa_activities', 'processing_status')
    op.drop_column('ropa_activities', 'processing_owner')
    op.drop_column('ropa_activities', 'business_function')


