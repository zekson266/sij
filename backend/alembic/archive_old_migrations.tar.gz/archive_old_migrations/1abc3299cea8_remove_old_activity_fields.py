"""remove_old_activity_fields

Revision ID: 1abc3299cea8
Revises: 6f1b304f7aef
Create Date: 2026-01-19 06:09:14.653715

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '1abc3299cea8'
down_revision: Union[str, None] = '6f1b304f7aef'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Drop old columns from ropa_activities table
    op.drop_column('ropa_activities', 'description')
    op.drop_column('ropa_activities', 'business_function')
    op.drop_column('ropa_activities', 'processing_owner')
    op.drop_column('ropa_activities', 'processing_status')
    op.drop_column('ropa_activities', 'processing_operations')
    op.drop_column('ropa_activities', 'processing_systems')
    op.drop_column('ropa_activities', 'processing_locations')
    op.drop_column('ropa_activities', 'degree_of_automation')
    op.drop_column('ropa_activities', 'use_of_profiling')
    op.drop_column('ropa_activities', 'storage_system')
    op.drop_column('ropa_activities', 'data_format')
    op.drop_column('ropa_activities', 'retention_period')
    op.drop_column('ropa_activities', 'deletion_method')
    op.drop_column('ropa_activities', 'internal_access_roles')
    op.drop_column('ropa_activities', 'external_recipients')
    op.drop_column('ropa_activities', 'international_transfer')


def downgrade() -> None:
    # Re-add dropped columns (for rollback)
    op.add_column('ropa_activities', sa.Column('description', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('business_function', sa.String(255), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_owner', sa.String(255), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_status', sa.String(50), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_operations', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_systems', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_locations', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('degree_of_automation', sa.String(50), nullable=True))
    op.add_column('ropa_activities', sa.Column('use_of_profiling', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_activities', sa.Column('storage_system', sa.String(255), nullable=True))
    op.add_column('ropa_activities', sa.Column('data_format', sa.String(100), nullable=True))
    op.add_column('ropa_activities', sa.Column('retention_period', sa.String(100), nullable=True))
    op.add_column('ropa_activities', sa.Column('deletion_method', sa.String(100), nullable=True))
    op.add_column('ropa_activities', sa.Column('internal_access_roles', sa.JSON(), nullable=True))
    op.add_column('ropa_activities', sa.Column('external_recipients', sa.JSON(), nullable=True))
    op.add_column('ropa_activities', sa.Column('international_transfer', sa.Boolean(), nullable=False, server_default='false'))
    # Re-add index for processing_status
    op.create_index(op.f('ix_ropa_activities_processing_status'), 'ropa_activities', ['processing_status'], unique=False)
    # Re-add index for international_transfer
    op.create_index(op.f('ix_ropa_activities_international_transfer'), 'ropa_activities', ['international_transfer'], unique=False)
