"""add_new_activity_fields_part3

Revision ID: 27ec34a1cc85
Revises: 889b123a17f3
Create Date: 2026-01-19 16:09:16.123456

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '27ec34a1cc85'
down_revision: Union[str, None] = '889b123a17f3'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add new columns to ropa_activities table (Part 3)
    op.add_column('ropa_activities', sa.Column('comments', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_activities', sa.Column('data_retention_policy', sa.String(500), nullable=True))
    op.add_column('ropa_activities', sa.Column('processing_frequency', sa.String(50), nullable=True))
    op.add_column('ropa_activities', sa.Column('legal_jurisdiction', postgresql.JSONB(astext_type=sa.Text()), nullable=True))


def downgrade() -> None:
    # Remove added columns
    op.drop_column('ropa_activities', 'legal_jurisdiction')
    op.drop_column('ropa_activities', 'processing_frequency')
    op.drop_column('ropa_activities', 'data_retention_policy')
    op.drop_column('ropa_activities', 'comments')
