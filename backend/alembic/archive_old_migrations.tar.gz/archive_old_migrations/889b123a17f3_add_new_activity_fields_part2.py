"""add_new_activity_fields_part2

Revision ID: 889b123a17f3
Revises: a55fe660c564
Create Date: 2026-01-19 14:41:25.123456

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '889b123a17f3'
down_revision: Union[str, None] = 'a55fe660c564'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add new columns to ropa_activities table (Part 2)
    op.add_column('ropa_activities', sa.Column('automated_decision', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_activities', sa.Column('data_subject_rights', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('dpia_required', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_activities', sa.Column('dpia_comment', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('dpia_file', sa.String(500), nullable=True))
    op.add_column('ropa_activities', sa.Column('dpia_gpc_link', sa.String(500), nullable=True))
    op.add_column('ropa_activities', sa.Column('children_data', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('parental_consent', sa.Text(), nullable=True))


def downgrade() -> None:
    # Remove added columns
    op.drop_column('ropa_activities', 'parental_consent')
    op.drop_column('ropa_activities', 'children_data')
    op.drop_column('ropa_activities', 'dpia_gpc_link')
    op.drop_column('ropa_activities', 'dpia_file')
    op.drop_column('ropa_activities', 'dpia_comment')
    op.drop_column('ropa_activities', 'dpia_required')
    op.drop_column('ropa_activities', 'data_subject_rights')
    op.drop_column('ropa_activities', 'automated_decision')
