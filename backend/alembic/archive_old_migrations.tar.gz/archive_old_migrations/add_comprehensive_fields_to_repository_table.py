"""add comprehensive fields to repository table

Revision ID: a1b2c3d4e5f6
Revises: 27b4c8bf8175
Create Date: 2026-01-03 05:55:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy import inspect

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, None] = '27b4c8bf8175'  # Original - keep for existing DBs, but consolidated migration creates tables for fresh installs
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Check if table exists (for fresh installs with consolidated migration)
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    existing_tables = inspector.get_table_names()
    
    if 'ropa_repositories' not in existing_tables:
        # Table doesn't exist - consolidated migration will create it
        # Skip this migration for fresh installs
        return
    
    # Get existing columns
    existing_columns = [col['name'] for col in inspector.get_columns('ropa_repositories')]
    
    # If table already has final schema columns (from consolidated migration), skip this migration
    # Key indicators: data_repository_name, geographical_system_location, access_locations
    if 'data_repository_name' in existing_columns and 'geographical_system_location' in existing_columns:
        # Table already has final schema - skip this migration
        return
    
    # Create enum types (only if they don't exist)
    # Note: For fresh installs, consolidated migration creates tables without these enum types
    # So we skip enum creation for fresh installs
    try:
        op.execute("CREATE TYPE repositorytype AS ENUM ('database', 'cloud_storage', 'file_system', 'data_warehouse', 'backup_storage', 'archive')")
    except Exception:
        pass  # Type already exists
    try:
        op.execute("CREATE TYPE repositorystatus AS ENUM ('active', 'archived', 'decommissioned', 'maintenance')")
    except Exception:
        pass
    try:
        op.execute("CREATE TYPE storagetype AS ENUM ('relational_db', 'nosql', 'object_storage', 'file_storage', 'block_storage')")
    except Exception:
        pass
    try:
        op.execute("CREATE TYPE environment AS ENUM ('production', 'staging', 'development', 'test')")
    except Exception:
        pass
    try:
        op.execute("CREATE TYPE accesscontrolmethod AS ENUM ('rbac', 'abac', 'ip_whitelist', 'vpn', 'certificate', 'api_key', 'other')")
    except Exception:
        pass
    try:
        op.execute("CREATE TYPE authenticationmethod AS ENUM ('mfa', 'sso', 'password', 'api_key', 'certificate', 'oauth', 'other')")
    except Exception:
        pass
    try:
        op.execute("CREATE TYPE backupfrequency AS ENUM ('continuous', 'hourly', 'daily', 'weekly', 'monthly', 'on_demand', 'none')")
    except Exception:
        pass
    try:
        op.execute("CREATE TYPE deletionmethod AS ENUM ('automated', 'manual', 'scheduled', 'on_demand', 'none')")
    except Exception:
        pass
    
    # ========== Basic Identification ==========
    # Only add columns if they don't exist (idempotent for fresh installs)
    if 'repository_type' not in existing_columns:
        op.add_column('ropa_repositories', sa.Column('repository_type', postgresql.ENUM('database', 'cloud_storage', 'file_system', 'data_warehouse', 'backup_storage', 'archive', name='repositorytype'), nullable=True))
    if 'vendor' not in existing_columns:
        op.add_column('ropa_repositories', sa.Column('vendor', sa.String(length=255), nullable=True))
    if 'version' not in existing_columns:
        op.add_column('ropa_repositories', sa.Column('version', sa.String(length=50), nullable=True))
    
    # ========== Geographic Location ==========
    # Check if 'location' column exists before altering (for fresh installs with consolidated migration)
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    existing_columns = [col['name'] for col in inspector.get_columns('ropa_repositories')]
    
    if 'location' in existing_columns:
        op.alter_column('ropa_repositories', 'location', type_=sa.String(length=255), existing_nullable=True)
    
    if 'primary_country' not in existing_columns:
        op.add_column('ropa_repositories', sa.Column('primary_country', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('secondary_countries', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('data_residency_region', sa.String(length=100), nullable=True))
    
    # ========== Storage and Infrastructure ==========
    op.add_column('ropa_repositories', sa.Column('storage_type', postgresql.ENUM('relational_db', 'nosql', 'object_storage', 'file_storage', 'block_storage', name='storagetype'), nullable=True))
    op.add_column('ropa_repositories', sa.Column('storage_capacity', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('is_cloud_based', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('cloud_provider', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('infrastructure_provider', sa.String(length=255), nullable=True))
    
    # ========== Security Measures ==========
    op.add_column('ropa_repositories', sa.Column('encryption_at_rest', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('encryption_in_transit', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('encryption_algorithm', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('access_control_method', postgresql.ENUM('rbac', 'abac', 'ip_whitelist', 'vpn', 'certificate', 'api_key', 'other', name='accesscontrolmethod'), nullable=True))
    op.add_column('ropa_repositories', sa.Column('authentication_method', postgresql.ENUM('mfa', 'sso', 'password', 'api_key', 'certificate', 'oauth', 'other', name='authenticationmethod'), nullable=True))
    op.add_column('ropa_repositories', sa.Column('security_measures', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('has_intrusion_detection', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('has_logging_monitoring', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('log_retention_period', sa.String(length=50), nullable=True))
    
    # ========== Access and Permissions ==========
    op.add_column('ropa_repositories', sa.Column('access_controls', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('responsible_person', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('responsible_team', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('access_logs_available', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('audit_trail_enabled', sa.Boolean(), nullable=False, server_default='false'))
    
    # ========== Backup and Disaster Recovery ==========
    op.add_column('ropa_repositories', sa.Column('backup_enabled', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('backup_frequency', postgresql.ENUM('continuous', 'hourly', 'daily', 'weekly', 'monthly', 'on_demand', 'none', name='backupfrequency'), nullable=True))
    op.add_column('ropa_repositories', sa.Column('backup_location', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('backup_retention_period', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('disaster_recovery_plan', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('rpo', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('rto', sa.String(length=50), nullable=True))
    
    # ========== Compliance and Certifications ==========
    op.add_column('ropa_repositories', sa.Column('compliance_certifications', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('gdpr_compliant', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('data_processing_agreement', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('certification_expiry_date', sa.DateTime(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('last_compliance_audit', sa.DateTime(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('next_compliance_audit', sa.DateTime(), nullable=True))
    
    # ========== Data Retention and Deletion ==========
    op.add_column('ropa_repositories', sa.Column('default_retention_policy', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('automated_deletion_enabled', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_repositories', sa.Column('deletion_method', postgresql.ENUM('automated', 'manual', 'scheduled', 'on_demand', 'none', name='deletionmethod'), nullable=True))
    op.add_column('ropa_repositories', sa.Column('data_anonymization_capability', sa.Boolean(), nullable=False, server_default='false'))
    
    # ========== Operational Status ==========
    op.add_column('ropa_repositories', sa.Column('status', postgresql.ENUM('active', 'archived', 'decommissioned', 'maintenance', name='repositorystatus'), nullable=False, server_default='active'))
    op.add_column('ropa_repositories', sa.Column('is_production', sa.Boolean(), nullable=False, server_default='true'))
    op.add_column('ropa_repositories', sa.Column('environment', postgresql.ENUM('production', 'staging', 'development', 'test', name='environment'), nullable=True))
    op.add_column('ropa_repositories', sa.Column('decommissioned_at', sa.DateTime(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('decommission_reason', sa.Text(), nullable=True))
    
    # ========== Additional Metadata ==========
    op.add_column('ropa_repositories', sa.Column('tags', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('notes', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('documentation_url', sa.String(length=500), nullable=True))
    op.add_column('ropa_repositories', sa.Column('contact_email', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('cost_center', sa.String(length=100), nullable=True))
    
    # Create indexes
    op.create_index(op.f('ix_ropa_repositories_repository_type'), 'ropa_repositories', ['repository_type'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_primary_country'), 'ropa_repositories', ['primary_country'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_is_cloud_based'), 'ropa_repositories', ['is_cloud_based'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_encryption_at_rest'), 'ropa_repositories', ['encryption_at_rest'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_encryption_in_transit'), 'ropa_repositories', ['encryption_in_transit'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_backup_enabled'), 'ropa_repositories', ['backup_enabled'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_gdpr_compliant'), 'ropa_repositories', ['gdpr_compliant'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_status'), 'ropa_repositories', ['status'], unique=False)
    op.create_index(op.f('ix_ropa_repositories_is_production'), 'ropa_repositories', ['is_production'], unique=False)


def downgrade() -> None:
    # Drop indexes
    op.drop_index(op.f('ix_ropa_repositories_is_production'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_status'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_gdpr_compliant'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_backup_enabled'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_encryption_in_transit'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_encryption_at_rest'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_is_cloud_based'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_primary_country'), table_name='ropa_repositories')
    op.drop_index(op.f('ix_ropa_repositories_repository_type'), table_name='ropa_repositories')
    
    # Drop columns
    op.drop_column('ropa_repositories', 'cost_center')
    op.drop_column('ropa_repositories', 'contact_email')
    op.drop_column('ropa_repositories', 'documentation_url')
    op.drop_column('ropa_repositories', 'notes')
    op.drop_column('ropa_repositories', 'tags')
    op.drop_column('ropa_repositories', 'decommission_reason')
    op.drop_column('ropa_repositories', 'decommissioned_at')
    op.drop_column('ropa_repositories', 'environment')
    op.drop_column('ropa_repositories', 'is_production')
    op.drop_column('ropa_repositories', 'status')
    op.drop_column('ropa_repositories', 'data_anonymization_capability')
    op.drop_column('ropa_repositories', 'deletion_method')
    op.drop_column('ropa_repositories', 'automated_deletion_enabled')
    op.drop_column('ropa_repositories', 'default_retention_policy')
    op.drop_column('ropa_repositories', 'next_compliance_audit')
    op.drop_column('ropa_repositories', 'last_compliance_audit')
    op.drop_column('ropa_repositories', 'certification_expiry_date')
    op.drop_column('ropa_repositories', 'data_processing_agreement')
    op.drop_column('ropa_repositories', 'gdpr_compliant')
    op.drop_column('ropa_repositories', 'compliance_certifications')
    op.drop_column('ropa_repositories', 'rto')
    op.drop_column('ropa_repositories', 'rpo')
    op.drop_column('ropa_repositories', 'disaster_recovery_plan')
    op.drop_column('ropa_repositories', 'backup_retention_period')
    op.drop_column('ropa_repositories', 'backup_location')
    op.drop_column('ropa_repositories', 'backup_frequency')
    op.drop_column('ropa_repositories', 'backup_enabled')
    op.drop_column('ropa_repositories', 'audit_trail_enabled')
    op.drop_column('ropa_repositories', 'access_logs_available')
    op.drop_column('ropa_repositories', 'responsible_team')
    op.drop_column('ropa_repositories', 'responsible_person')
    op.drop_column('ropa_repositories', 'access_controls')
    op.drop_column('ropa_repositories', 'log_retention_period')
    op.drop_column('ropa_repositories', 'has_logging_monitoring')
    op.drop_column('ropa_repositories', 'has_intrusion_detection')
    op.drop_column('ropa_repositories', 'security_measures')
    op.drop_column('ropa_repositories', 'authentication_method')
    op.drop_column('ropa_repositories', 'access_control_method')
    op.drop_column('ropa_repositories', 'encryption_algorithm')
    op.drop_column('ropa_repositories', 'encryption_in_transit')
    op.drop_column('ropa_repositories', 'encryption_at_rest')
    op.drop_column('ropa_repositories', 'infrastructure_provider')
    op.drop_column('ropa_repositories', 'cloud_provider')
    op.drop_column('ropa_repositories', 'is_cloud_based')
    op.drop_column('ropa_repositories', 'storage_capacity')
    op.drop_column('ropa_repositories', 'storage_type')
    op.drop_column('ropa_repositories', 'data_residency_region')
    op.drop_column('ropa_repositories', 'secondary_countries')
    op.drop_column('ropa_repositories', 'primary_country')
    op.alter_column('ropa_repositories', 'location', type_=sa.String(length=100), existing_nullable=True)
    op.drop_column('ropa_repositories', 'version')
    op.drop_column('ropa_repositories', 'vendor')
    op.drop_column('ropa_repositories', 'repository_type')
    
    # Drop enum types
    op.execute("DROP TYPE IF EXISTS deletionmethod")
    op.execute("DROP TYPE IF EXISTS backupfrequency")
    op.execute("DROP TYPE IF EXISTS authenticationmethod")
    op.execute("DROP TYPE IF EXISTS accesscontrolmethod")
    op.execute("DROP TYPE IF EXISTS environment")
    op.execute("DROP TYPE IF EXISTS storagetype")
    op.execute("DROP TYPE IF EXISTS repositorystatus")
    op.execute("DROP TYPE IF EXISTS repositorytype")



