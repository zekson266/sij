"""add comprehensive fields to data element table

Revision ID: a1b2c3d4e5f9
Revises: a1b2c3d4e5f8
Create Date: 2026-01-04 17:05:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f9'
down_revision: Union[str, None] = 'a1b2c3d4e5f8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ========== Data Classification ==========
    op.add_column('ropa_data_elements', sa.Column('data_subject_category', sa.String(length=100), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('is_personal_data', sa.Boolean(), nullable=False, server_default='true'))
    op.create_index(op.f('ix_ropa_data_elements_is_personal_data'), 'ropa_data_elements', ['is_personal_data'], unique=False)
    op.add_column('ropa_data_elements', sa.Column('is_special_category_data', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index(op.f('ix_ropa_data_elements_is_special_category_data'), 'ropa_data_elements', ['is_special_category_data'], unique=False)
    op.add_column('ropa_data_elements', sa.Column('is_children_data', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index(op.f('ix_ropa_data_elements_is_children_data'), 'ropa_data_elements', ['is_children_data'], unique=False)
    
    # ========== Data Collection ==========
    op.add_column('ropa_data_elements', sa.Column('data_source', sa.String(length=255), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('collection_method', sa.String(length=100), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('collection_frequency', sa.String(length=50), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('approximate_data_subject_volume', sa.String(length=100), nullable=True))


def downgrade() -> None:
    # Drop indexes
    op.drop_index(op.f('ix_ropa_data_elements_is_children_data'), table_name='ropa_data_elements')
    op.drop_index(op.f('ix_ropa_data_elements_is_special_category_data'), table_name='ropa_data_elements')
    op.drop_index(op.f('ix_ropa_data_elements_is_personal_data'), table_name='ropa_data_elements')
    
    # Drop columns
    op.drop_column('ropa_data_elements', 'approximate_data_subject_volume')
    op.drop_column('ropa_data_elements', 'collection_frequency')
    op.drop_column('ropa_data_elements', 'collection_method')
    op.drop_column('ropa_data_elements', 'data_source')
    op.drop_column('ropa_data_elements', 'is_children_data')
    op.drop_column('ropa_data_elements', 'is_special_category_data')
    op.drop_column('ropa_data_elements', 'is_personal_data')
    op.drop_column('ropa_data_elements', 'data_subject_category')


