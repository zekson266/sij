"""add_lookup_tables_for_ropa

Revision ID: d41ccb50f989
Revises: a1b2c3d4e5fc
Create Date: 2026-01-19 02:19:41.316343

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'd41ccb50f989'
down_revision: Union[str, None] = 'a1b2c3d4e5fc'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create ropa_departments table
    op.create_table(
        'ropa_departments',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text('gen_random_uuid()')),
        sa.Column('tenant_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], ondelete='CASCADE'),
        sa.UniqueConstraint('tenant_id', 'name', name='uq_department_tenant_name'),
    )
    op.create_index(op.f('ix_ropa_departments_id'), 'ropa_departments', ['id'], unique=False)
    op.create_index(op.f('ix_ropa_departments_tenant_id'), 'ropa_departments', ['tenant_id'], unique=False)
    
    # Create ropa_locations table (global, not tenant-specific)
    op.create_table(
        'ropa_locations',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text('gen_random_uuid()')),
        sa.Column('name', sa.String(length=255), nullable=False, unique=True),
        sa.Column('country_code', sa.String(length=10), nullable=True),
        sa.Column('region', sa.String(length=100), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
    )
    op.create_index(op.f('ix_ropa_locations_id'), 'ropa_locations', ['id'], unique=False)
    
    # Create ropa_systems table
    op.create_table(
        'ropa_systems',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text('gen_random_uuid()')),
        sa.Column('tenant_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('system_type', sa.String(length=100), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], ondelete='CASCADE'),
        sa.UniqueConstraint('tenant_id', 'name', name='uq_system_tenant_name'),
    )
    op.create_index(op.f('ix_ropa_systems_id'), 'ropa_systems', ['id'], unique=False)
    op.create_index(op.f('ix_ropa_systems_tenant_id'), 'ropa_systems', ['tenant_id'], unique=False)
    


def downgrade() -> None:
    # Drop indexes first
    op.drop_index(op.f('ix_ropa_systems_tenant_id'), table_name='ropa_systems')
    op.drop_index(op.f('ix_ropa_systems_id'), table_name='ropa_systems')
    op.drop_index(op.f('ix_ropa_locations_id'), table_name='ropa_locations')
    op.drop_index(op.f('ix_ropa_departments_tenant_id'), table_name='ropa_departments')
    op.drop_index(op.f('ix_ropa_departments_id'), table_name='ropa_departments')
    
    # Drop tables
    op.drop_table('ropa_systems')
    op.drop_table('ropa_locations')
    op.drop_table('ropa_departments')
