"""add ai_suggestion_jobs table

Revision ID: a1b2c3d4e5f7
Revises: 158c29ad9142
Create Date: 2025-01-04 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f7'
down_revision: Union[str, None] = '158c29ad9142'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create ai_suggestion_jobs table
    op.create_table(
        'ai_suggestion_jobs',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('tenant_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('repository_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('field_name', sa.String(100), nullable=False),
        sa.Column('field_type', sa.String(50), nullable=False),
        sa.Column('field_label', sa.String(255), nullable=False),
        sa.Column('status', sa.String(50), nullable=False),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('request_data', postgresql.JSONB, nullable=False),
        sa.Column('general_statement', sa.Text(), nullable=True),
        sa.Column('suggestions', postgresql.JSONB, nullable=True),
        sa.Column('openai_model', sa.String(50), nullable=True),
        sa.Column('openai_tokens_used', sa.Integer(), nullable=True),
        sa.Column('openai_cost_usd', sa.Numeric(10, 6), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['repository_id'], ['ropa_repositories.id'], ondelete='CASCADE'),
    )
    
    # Create indexes
    op.create_index('idx_ai_suggestion_jobs_id', 'ai_suggestion_jobs', ['id'])
    op.create_index('idx_ai_suggestion_jobs_user_id', 'ai_suggestion_jobs', ['user_id'])
    op.create_index('idx_ai_suggestion_jobs_tenant_id', 'ai_suggestion_jobs', ['tenant_id'])
    op.create_index('idx_ai_suggestion_jobs_repository_id', 'ai_suggestion_jobs', ['repository_id'])
    op.create_index('idx_ai_suggestion_jobs_field_name', 'ai_suggestion_jobs', ['field_name'])
    op.create_index('idx_ai_suggestion_jobs_status', 'ai_suggestion_jobs', ['status'])
    op.create_index('idx_ai_suggestion_jobs_created_at', 'ai_suggestion_jobs', ['created_at'])


def downgrade() -> None:
    # Drop indexes
    op.drop_index('idx_ai_suggestion_jobs_created_at', table_name='ai_suggestion_jobs')
    op.drop_index('idx_ai_suggestion_jobs_status', table_name='ai_suggestion_jobs')
    op.drop_index('idx_ai_suggestion_jobs_field_name', table_name='ai_suggestion_jobs')
    op.drop_index('idx_ai_suggestion_jobs_repository_id', table_name='ai_suggestion_jobs')
    op.drop_index('idx_ai_suggestion_jobs_tenant_id', table_name='ai_suggestion_jobs')
    op.drop_index('idx_ai_suggestion_jobs_user_id', table_name='ai_suggestion_jobs')
    op.drop_index('idx_ai_suggestion_jobs_id', table_name='ai_suggestion_jobs')
    
    # Drop table
    op.drop_table('ai_suggestion_jobs')


