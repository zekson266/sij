"""make_data_format_required

Revision ID: 569e5b7d1508
Revises: 8579749046d5
Create Date: 2026-01-19 05:19:31.063858

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '569e5b7d1508'
down_revision: Union[str, None] = '8579749046d5'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Step 1: Set default value for existing NULL data_format values
    # Use 'Electronic' as default (most common case)
    op.execute("""
        UPDATE ropa_repositories 
        SET data_format = 'Electronic' 
        WHERE data_format IS NULL
    """)
    
    # Step 2: Make data_format NOT NULL
    op.alter_column('ropa_repositories', 'data_format', nullable=False)


def downgrade() -> None:
    # Make data_format nullable again
    op.alter_column('ropa_repositories', 'data_format', nullable=True)

