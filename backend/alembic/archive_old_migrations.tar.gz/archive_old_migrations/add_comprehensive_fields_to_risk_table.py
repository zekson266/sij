"""add comprehensive fields to risk table

Revision ID: a1b2c3d4e5fb
Revises: a1b2c3d4e5fa
Create Date: 2026-01-04 17:15:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5fb'
down_revision: Union[str, None] = 'a1b2c3d4e5fa'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ========== Risk Assessment ==========
    op.add_column('ropa_risks', sa.Column('residual_severity', sa.String(length=50), nullable=True))
    op.add_column('ropa_risks', sa.Column('residual_likelihood', sa.String(length=50), nullable=True))
    
    # ========== Risk Management ==========
    op.add_column('ropa_risks', sa.Column('risk_owner', sa.String(length=255), nullable=True))
    op.add_column('ropa_risks', sa.Column('risk_status', sa.String(length=50), nullable=True))
    op.create_index(op.f('ix_ropa_risks_risk_status'), 'ropa_risks', ['risk_status'], unique=False)
    
    # Add index to severity if it doesn't exist
    try:
        op.create_index(op.f('ix_ropa_risks_severity'), 'ropa_risks', ['severity'], unique=False)
    except:
        pass  # Index may already exist


def downgrade() -> None:
    # Drop indexes
    op.drop_index(op.f('ix_ropa_risks_risk_status'), table_name='ropa_risks')
    try:
        op.drop_index(op.f('ix_ropa_risks_severity'), table_name='ropa_risks')
    except:
        pass  # Index may not exist
    
    # Drop columns
    op.drop_column('ropa_risks', 'risk_status')
    op.drop_column('ropa_risks', 'risk_owner')
    op.drop_column('ropa_risks', 'residual_likelihood')
    op.drop_column('ropa_risks', 'residual_severity')


