"""remove_technical_fields_from_repository

Revision ID: 9792c46002cb
Revises: d41ccb50f989
Create Date: 2026-01-19 02:27:15.123456

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '9792c46002cb'
down_revision: Union[str, None] = 'd41ccb50f989'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Drop indexes first
    op.drop_index('ix_ropa_repositories_is_production', table_name='ropa_repositories')
    op.drop_index('ix_ropa_repositories_is_cloud_based', table_name='ropa_repositories')
    op.drop_index('ix_ropa_repositories_encryption_in_transit', table_name='ropa_repositories')
    op.drop_index('ix_ropa_repositories_encryption_at_rest', table_name='ropa_repositories')
    op.drop_index('ix_ropa_repositories_backup_enabled', table_name='ropa_repositories')
    op.drop_index('ix_ropa_repositories_gdpr_compliant', table_name='ropa_repositories')
    op.drop_index('ix_ropa_repositories_primary_country', table_name='ropa_repositories')
    op.drop_index('ix_ropa_repositories_repository_type', table_name='ropa_repositories')
    
    # Drop columns
    op.drop_column('ropa_repositories', 'repository_type')
    op.drop_column('ropa_repositories', 'version')
    op.drop_column('ropa_repositories', 'location')
    op.drop_column('ropa_repositories', 'primary_country')
    op.drop_column('ropa_repositories', 'secondary_countries')
    op.drop_column('ropa_repositories', 'data_residency_region')
    op.drop_column('ropa_repositories', 'storage_type')
    op.drop_column('ropa_repositories', 'storage_capacity')
    op.drop_column('ropa_repositories', 'is_cloud_based')
    op.drop_column('ropa_repositories', 'cloud_provider')
    op.drop_column('ropa_repositories', 'infrastructure_provider')
    op.drop_column('ropa_repositories', 'encryption_at_rest')
    op.drop_column('ropa_repositories', 'encryption_in_transit')
    op.drop_column('ropa_repositories', 'encryption_algorithm')
    op.drop_column('ropa_repositories', 'access_control_method')
    op.drop_column('ropa_repositories', 'authentication_method')
    op.drop_column('ropa_repositories', 'security_measures')
    op.drop_column('ropa_repositories', 'has_intrusion_detection')
    op.drop_column('ropa_repositories', 'has_logging_monitoring')
    op.drop_column('ropa_repositories', 'log_retention_period')
    op.drop_column('ropa_repositories', 'access_controls')
    op.drop_column('ropa_repositories', 'responsible_person')
    op.drop_column('ropa_repositories', 'responsible_team')
    op.drop_column('ropa_repositories', 'access_logs_available')
    op.drop_column('ropa_repositories', 'audit_trail_enabled')
    op.drop_column('ropa_repositories', 'backup_enabled')
    op.drop_column('ropa_repositories', 'backup_frequency')
    op.drop_column('ropa_repositories', 'backup_location')
    op.drop_column('ropa_repositories', 'backup_retention_period')
    op.drop_column('ropa_repositories', 'disaster_recovery_plan')
    op.drop_column('ropa_repositories', 'rpo')
    op.drop_column('ropa_repositories', 'rto')
    op.drop_column('ropa_repositories', 'compliance_certifications')
    op.drop_column('ropa_repositories', 'certification_expiry_date')
    op.drop_column('ropa_repositories', 'last_compliance_audit')
    op.drop_column('ropa_repositories', 'next_compliance_audit')
    op.drop_column('ropa_repositories', 'default_retention_policy')
    op.drop_column('ropa_repositories', 'automated_deletion_enabled')
    op.drop_column('ropa_repositories', 'deletion_method')
    op.drop_column('ropa_repositories', 'data_anonymization_capability')
    op.drop_column('ropa_repositories', 'is_production')
    op.drop_column('ropa_repositories', 'environment')
    op.drop_column('ropa_repositories', 'decommissioned_at')
    op.drop_column('ropa_repositories', 'decommission_reason')
    op.drop_column('ropa_repositories', 'documentation_url')
    op.drop_column('ropa_repositories', 'contact_email')
    op.drop_column('ropa_repositories', 'cost_center')


def downgrade() -> None:
    # Re-add columns (simplified - without all the original constraints/defaults)
    op.add_column('ropa_repositories', sa.Column('cost_center', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('contact_email', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('documentation_url', sa.String(length=500), nullable=True))
    op.add_column('ropa_repositories', sa.Column('decommission_reason', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('decommissioned_at', sa.DateTime(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('environment', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('is_production', sa.Boolean(), nullable=False, server_default=sa.text('true')))
    op.add_column('ropa_repositories', sa.Column('data_anonymization_capability', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('deletion_method', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('automated_deletion_enabled', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('default_retention_policy', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('next_compliance_audit', sa.DateTime(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('last_compliance_audit', sa.DateTime(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('certification_expiry_date', sa.DateTime(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('compliance_certifications', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('rto', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('rpo', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('disaster_recovery_plan', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('backup_retention_period', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('backup_location', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('backup_frequency', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('backup_enabled', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('audit_trail_enabled', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('access_logs_available', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('responsible_team', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('responsible_person', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('access_controls', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('log_retention_period', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('has_logging_monitoring', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('has_intrusion_detection', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('security_measures', sa.Text(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('authentication_method', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('access_control_method', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('encryption_algorithm', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('encryption_in_transit', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('encryption_at_rest', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('infrastructure_provider', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('cloud_provider', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('is_cloud_based', sa.Boolean(), nullable=False, server_default=sa.text('false')))
    op.add_column('ropa_repositories', sa.Column('storage_capacity', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('storage_type', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('data_residency_region', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('secondary_countries', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('primary_country', sa.String(length=100), nullable=True))
    op.add_column('ropa_repositories', sa.Column('location', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('version', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('repository_type', sa.String(length=50), nullable=True))
    
    # Re-create indexes
    op.create_index('ix_ropa_repositories_repository_type', 'ropa_repositories', ['repository_type'], unique=False)
    op.create_index('ix_ropa_repositories_primary_country', 'ropa_repositories', ['primary_country'], unique=False)
    op.create_index('ix_ropa_repositories_gdpr_compliant', 'ropa_repositories', ['gdpr_compliant'], unique=False)
    op.create_index('ix_ropa_repositories_backup_enabled', 'ropa_repositories', ['backup_enabled'], unique=False)
    op.create_index('ix_ropa_repositories_encryption_at_rest', 'ropa_repositories', ['encryption_at_rest'], unique=False)
    op.create_index('ix_ropa_repositories_encryption_in_transit', 'ropa_repositories', ['encryption_in_transit'], unique=False)
    op.create_index('ix_ropa_repositories_is_cloud_based', 'ropa_repositories', ['is_cloud_based'], unique=False)
    op.create_index('ix_ropa_repositories_is_production', 'ropa_repositories', ['is_production'], unique=False)
