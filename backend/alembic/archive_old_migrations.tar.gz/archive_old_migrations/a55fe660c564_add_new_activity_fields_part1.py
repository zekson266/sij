"""add_new_activity_fields_part1

Revision ID: a55fe660c564
Revises: 1abc3299cea8
Create Date: 2026-01-19 06:17:24.123456

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = 'a55fe660c564'
down_revision: Union[str, None] = '1abc3299cea8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add new columns to ropa_activities table
    op.add_column('ropa_activities', sa.Column('legitimate_interest_assessment', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('data_subject_type', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_activities', sa.Column('collection_sources', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_activities', sa.Column('data_disclosed_to', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_activities', sa.Column('jit_notice', sa.Text(), nullable=True))
    op.add_column('ropa_activities', sa.Column('consent_process', sa.Text(), nullable=True))


def downgrade() -> None:
    # Remove added columns
    op.drop_column('ropa_activities', 'consent_process')
    op.drop_column('ropa_activities', 'jit_notice')
    op.drop_column('ropa_activities', 'data_disclosed_to')
    op.drop_column('ropa_activities', 'collection_sources')
    op.drop_column('ropa_activities', 'data_subject_type')
    op.drop_column('ropa_activities', 'legitimate_interest_assessment')
