"""remove_old_data_element_fields

Revision ID: 8577068ab292
Revises: f8f7917db8ed
Create Date: 2026-01-20 02:33:04.547219

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '8577068ab292'
down_revision: Union[str, None] = 'f8f7917db8ed'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Remove old fields from ropa_data_elements table
    op.drop_column('ropa_data_elements', 'name')
    op.drop_column('ropa_data_elements', 'description')
    op.drop_column('ropa_data_elements', 'data_subject_category')
    op.drop_column('ropa_data_elements', 'is_personal_data')
    op.drop_column('ropa_data_elements', 'is_special_category_data')
    op.drop_column('ropa_data_elements', 'is_children_data')
    op.drop_column('ropa_data_elements', 'data_source')
    op.drop_column('ropa_data_elements', 'collection_method')
    op.drop_column('ropa_data_elements', 'collection_frequency')
    op.drop_column('ropa_data_elements', 'approximate_data_subject_volume')


def downgrade() -> None:
    # Re-add old fields (with nullable=True for safety)
    op.add_column('ropa_data_elements', sa.Column('name', sa.String(255), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('description', sa.Text(), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('data_subject_category', sa.String(100), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('is_personal_data', sa.Boolean(), nullable=True, server_default='true'))
    op.add_column('ropa_data_elements', sa.Column('is_special_category_data', sa.Boolean(), nullable=True, server_default='false'))
    op.add_column('ropa_data_elements', sa.Column('is_children_data', sa.Boolean(), nullable=True, server_default='false'))
    op.add_column('ropa_data_elements', sa.Column('data_source', sa.String(255), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('collection_method', sa.String(100), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('collection_frequency', sa.String(50), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('approximate_data_subject_volume', sa.String(100), nullable=True))

