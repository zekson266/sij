"""rename_activity_fields

Revision ID: 6f1b304f7aef
Revises: 569e5b7d1508
Create Date: 2026-01-19 05:21:38.278570

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '6f1b304f7aef'
down_revision: Union[str, None] = '569e5b7d1508'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Rename columns using ALTER TABLE
    op.execute("ALTER TABLE ropa_activities RENAME COLUMN repository_id TO data_repository_id")
    op.execute("ALTER TABLE ropa_activities RENAME COLUMN name TO processing_activity_name")
    op.execute("ALTER TABLE ropa_activities RENAME COLUMN legal_basis TO lawful_basis")


def downgrade() -> None:
    # Rename columns back
    op.execute("ALTER TABLE ropa_activities RENAME COLUMN data_repository_id TO repository_id")
    op.execute("ALTER TABLE ropa_activities RENAME COLUMN processing_activity_name TO name")
    op.execute("ALTER TABLE ropa_activities RENAME COLUMN lawful_basis TO legal_basis")

