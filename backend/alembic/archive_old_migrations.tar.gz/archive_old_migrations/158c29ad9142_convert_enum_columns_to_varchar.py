"""convert enum columns to varchar

Revision ID: 158c29ad9142
Revises: a1b2c3d4e5f6
Create Date: 2026-01-03 07:10:49.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy import inspect

# revision identifiers, used by Alembic.
revision: str = '158c29ad9142'
down_revision: Union[str, None] = 'a1b2c3d4e5f6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Check if ropa_repositories table exists and has final schema
    # If it has data_repository_name, it's from consolidated migration - skip this migration
    conn = op.get_bind()
    inspector = sa.inspect(conn)
    existing_tables = inspector.get_table_names()
    
    if 'ropa_repositories' in existing_tables:
        existing_columns = [col['name'] for col in inspector.get_columns('ropa_repositories')]
        # If table has final schema (from consolidated migration), skip this migration
        if 'data_repository_name' in existing_columns:
            return
    # Convert enum columns to VARCHAR to allow SQLAlchemy to handle enum values properly
    # This allows us to use enum values ('active') instead of enum names ('ACTIVE')
    
    # Convert status column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN status TYPE VARCHAR(50) 
        USING status::text
    """)
    
    # Convert repository_type column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN repository_type TYPE VARCHAR(50) 
        USING repository_type::text
    """)
    
    # Convert storage_type column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN storage_type TYPE VARCHAR(50) 
        USING storage_type::text
    """)
    
    # Convert environment column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN environment TYPE VARCHAR(50) 
        USING environment::text
    """)
    
    # Convert access_control_method column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN access_control_method TYPE VARCHAR(50) 
        USING access_control_method::text
    """)
    
    # Convert authentication_method column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN authentication_method TYPE VARCHAR(50) 
        USING authentication_method::text
    """)
    
    # Convert backup_frequency column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN backup_frequency TYPE VARCHAR(50) 
        USING backup_frequency::text
    """)
    
    # Convert deletion_method column
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN deletion_method TYPE VARCHAR(50) 
        USING deletion_method::text
    """)


def downgrade() -> None:
    # Convert back to enum types (if needed)
    # Note: This assumes the enum types still exist
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN status TYPE repositorystatus 
        USING status::repositorystatus
    """)
    
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN repository_type TYPE repositorytype 
        USING repository_type::repositorytype
    """)
    
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN storage_type TYPE storagetype 
        USING storage_type::storagetype
    """)
    
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN environment TYPE environment 
        USING environment::environment
    """)
    
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN access_control_method TYPE accesscontrolmethod 
        USING access_control_method::accesscontrolmethod
    """)
    
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN authentication_method TYPE authenticationmethod 
        USING authentication_method::authenticationmethod
    """)
    
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN backup_frequency TYPE backupfrequency 
        USING backup_frequency::backupfrequency
    """)
    
    op.execute("""
        ALTER TABLE ropa_repositories 
        ALTER COLUMN deletion_method TYPE deletionmethod 
        USING deletion_method::deletionmethod
    """)



