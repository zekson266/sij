"""add_new_data_element_fields

Revision ID: 777e29621175
Revises: 8577068ab292
Create Date: 2026-01-20 03:04:12.084599

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = '777e29621175'
down_revision: Union[str, None] = '8577068ab292'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add new columns to ropa_data_elements table
    op.add_column('ropa_data_elements', sa.Column('data_elements', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('special_lawful_basis', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('secondary_use', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_data_elements', sa.Column('encryption_in_transit', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('ropa_data_elements', sa.Column('safeguards', sa.Text(), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('retention_period_days', sa.Integer(), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('disposition_method', sa.Text(), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('comments', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('data_minimization_justification', sa.Text(), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('data_accuracy_requirements', sa.Text(), nullable=True))
    op.add_column('ropa_data_elements', sa.Column('data_storage_location', postgresql.JSONB(astext_type=sa.Text()), nullable=True))


def downgrade() -> None:
    # Remove added columns
    op.drop_column('ropa_data_elements', 'data_storage_location')
    op.drop_column('ropa_data_elements', 'data_accuracy_requirements')
    op.drop_column('ropa_data_elements', 'data_minimization_justification')
    op.drop_column('ropa_data_elements', 'comments')
    op.drop_column('ropa_data_elements', 'disposition_method')
    op.drop_column('ropa_data_elements', 'retention_period_days')
    op.drop_column('ropa_data_elements', 'safeguards')
    op.drop_column('ropa_data_elements', 'encryption_in_transit')
    op.drop_column('ropa_data_elements', 'secondary_use')
    op.drop_column('ropa_data_elements', 'special_lawful_basis')
    op.drop_column('ropa_data_elements', 'data_elements')

