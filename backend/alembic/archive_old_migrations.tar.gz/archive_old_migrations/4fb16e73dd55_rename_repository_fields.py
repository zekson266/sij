"""rename_repository_fields

Revision ID: 4fb16e73dd55
Revises: 9792c46002cb
Create Date: 2026-01-19 02:48:56.881840

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '4fb16e73dd55'
down_revision: Union[str, None] = '9792c46002cb'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Rename columns using ALTER TABLE
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN name TO data_repository_name")
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN description TO data_repository_description")
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN vendor TO external_vendor")
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN data_processing_agreement TO dpa_url")
    
    # Merge tags and notes into comments
    # First, rename tags to comments (they're both JSONB)
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN tags TO comments")
    
    # Now merge notes (TEXT) into comments (JSONB array)
    # Convert notes to JSONB array and merge with existing comments
    op.execute("""
        UPDATE ropa_repositories
        SET comments = CASE
            WHEN notes IS NOT NULL AND notes != '' THEN
                CASE
                    WHEN comments IS NOT NULL AND jsonb_typeof(comments) = 'array' THEN
                        comments || jsonb_build_array(notes)
                    WHEN comments IS NOT NULL THEN
                        jsonb_build_array(comments::text, notes)
                    ELSE
                        jsonb_build_array(notes)
                END
            ELSE
                comments
        END
    """)
    
    # Drop the notes column
    op.drop_column('ropa_repositories', 'notes')


def downgrade() -> None:
    # Recreate notes column
    op.add_column('ropa_repositories', sa.Column('notes', sa.Text(), nullable=True))
    
    # Extract notes from comments (take last element if array, or convert to text)
    op.execute("""
        UPDATE ropa_repositories
        SET notes = CASE
            WHEN comments IS NOT NULL AND jsonb_typeof(comments) = 'array' AND jsonb_array_length(comments) > 0 THEN
                comments->>-1
            WHEN comments IS NOT NULL THEN
                comments::text
            ELSE
                NULL
        END
    """)
    
    # Rename comments back to tags
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN comments TO tags")
    
    # Rename columns back
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN dpa_url TO data_processing_agreement")
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN external_vendor TO vendor")
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN data_repository_description TO description")
    op.execute("ALTER TABLE ropa_repositories RENAME COLUMN data_repository_name TO name")
