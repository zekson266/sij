"""add_new_fields_to_repository

Revision ID: 8579749046d5
Revises: 4fb16e73dd55
Create Date: 2026-01-19 03:03:30.526985

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = '8579749046d5'
down_revision: Union[str, None] = '4fb16e73dd55'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Drop old index (if exists) and create new one
    op.drop_index('ix_ropa_repositories_name', table_name='ropa_repositories', if_exists=True)
    op.create_index(op.f('ix_ropa_repositories_data_repository_name'), 'ropa_repositories', ['data_repository_name'], unique=False)
    
    # Add new columns
    op.add_column('ropa_repositories', sa.Column('business_owner', postgresql.UUID(as_uuid=True), nullable=True))
    op.create_index(op.f('ix_ropa_repositories_business_owner'), 'ropa_repositories', ['business_owner'], unique=False)
    op.create_foreign_key('fk_ropa_repositories_business_owner', 'ropa_repositories', 'ropa_departments', ['business_owner'], ['id'], ondelete='SET NULL')
    
    op.add_column('ropa_repositories', sa.Column('data_format', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('geographical_system_location', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('access_locations', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('transfer_mechanism', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('derogation_type', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('cross_border_safeguards', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('cross_border_transfer_detail', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('dpa_file', sa.String(length=500), nullable=True))
    op.add_column('ropa_repositories', sa.Column('vendor_gdpr_compliance', sa.Boolean(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('certification', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('record_count', sa.Integer(), nullable=True))
    op.add_column('ropa_repositories', sa.Column('system_interfaces', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('interface_type', sa.String(length=50), nullable=True))
    op.add_column('ropa_repositories', sa.Column('interface_location', postgresql.JSONB(astext_type=sa.Text()), nullable=True))
    op.add_column('ropa_repositories', sa.Column('data_recipients', sa.String(length=255), nullable=True))
    op.add_column('ropa_repositories', sa.Column('sub_processors', sa.String(length=255), nullable=True))
    
    # Update dpa_url column length from 255 to 500
    op.alter_column('ropa_repositories', 'dpa_url', type_=sa.String(length=500), existing_type=sa.String(length=255), existing_nullable=True)


def downgrade() -> None:
    # Revert dpa_url column length
    op.alter_column('ropa_repositories', 'dpa_url', type_=sa.String(length=255), existing_type=sa.String(length=500), existing_nullable=True)
    
    # Drop new columns
    op.drop_column('ropa_repositories', 'sub_processors')
    op.drop_column('ropa_repositories', 'data_recipients')
    op.drop_column('ropa_repositories', 'interface_location')
    op.drop_column('ropa_repositories', 'interface_type')
    op.drop_column('ropa_repositories', 'system_interfaces')
    op.drop_column('ropa_repositories', 'record_count')
    op.drop_column('ropa_repositories', 'certification')
    op.drop_column('ropa_repositories', 'vendor_gdpr_compliance')
    op.drop_column('ropa_repositories', 'dpa_file')
    op.drop_column('ropa_repositories', 'cross_border_transfer_detail')
    op.drop_column('ropa_repositories', 'cross_border_safeguards')
    op.drop_column('ropa_repositories', 'derogation_type')
    op.drop_column('ropa_repositories', 'transfer_mechanism')
    op.drop_column('ropa_repositories', 'access_locations')
    op.drop_column('ropa_repositories', 'geographical_system_location')
    op.drop_column('ropa_repositories', 'data_format')
    
    op.drop_constraint('fk_ropa_repositories_business_owner', 'ropa_repositories', type_='foreignkey')
    op.drop_index(op.f('ix_ropa_repositories_business_owner'), table_name='ropa_repositories')
    op.drop_column('ropa_repositories', 'business_owner')
    
    # Revert index
    op.drop_index(op.f('ix_ropa_repositories_data_repository_name'), table_name='ropa_repositories')
    op.create_index('ix_ropa_repositories_name', 'ropa_repositories', ['data_repository_name'], unique=False)

