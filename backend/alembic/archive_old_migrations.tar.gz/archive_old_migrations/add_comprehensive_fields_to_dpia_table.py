"""add comprehensive fields to dpia table

Revision ID: a1b2c3d4e5fa
Revises: a1b2c3d4e5f9
Create Date: 2026-01-04 17:10:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5fa'
down_revision: Union[str, None] = 'a1b2c3d4e5f9'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ========== Assessment Details ==========
    op.add_column('ropa_dpias', sa.Column('necessity_proportionality_assessment', sa.Text(), nullable=True))
    op.add_column('ropa_dpias', sa.Column('assessor', sa.String(length=255), nullable=True))
    op.add_column('ropa_dpias', sa.Column('assessment_date', sa.DateTime(), nullable=True))
    
    # ========== Consultation Requirements ==========
    op.add_column('ropa_dpias', sa.Column('dpo_consultation_required', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index(op.f('ix_ropa_dpias_dpo_consultation_required'), 'ropa_dpias', ['dpo_consultation_required'], unique=False)
    op.add_column('ropa_dpias', sa.Column('dpo_consultation_date', sa.DateTime(), nullable=True))
    op.add_column('ropa_dpias', sa.Column('supervisory_authority_consultation_required', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index(op.f('ix_ropa_dpias_supervisory_authority_consultation_required'), 'ropa_dpias', ['supervisory_authority_consultation_required'], unique=False)
    op.add_column('ropa_dpias', sa.Column('supervisory_authority_consultation_date', sa.DateTime(), nullable=True))


def downgrade() -> None:
    # Drop indexes
    op.drop_index(op.f('ix_ropa_dpias_supervisory_authority_consultation_required'), table_name='ropa_dpias')
    op.drop_index(op.f('ix_ropa_dpias_dpo_consultation_required'), table_name='ropa_dpias')
    
    # Drop columns
    op.drop_column('ropa_dpias', 'supervisory_authority_consultation_date')
    op.drop_column('ropa_dpias', 'supervisory_authority_consultation_required')
    op.drop_column('ropa_dpias', 'dpo_consultation_date')
    op.drop_column('ropa_dpias', 'dpo_consultation_required')
    op.drop_column('ropa_dpias', 'assessment_date')
    op.drop_column('ropa_dpias', 'assessor')
    op.drop_column('ropa_dpias', 'necessity_proportionality_assessment')


