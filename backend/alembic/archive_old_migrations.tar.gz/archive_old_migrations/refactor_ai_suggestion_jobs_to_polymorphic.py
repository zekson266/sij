"""refactor ai_suggestion_jobs to polymorphic pattern

Revision ID: a1b2c3d4e5fc
Revises: a1b2c3d4e5fb
Create Date: 2026-01-04 18:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5fc'
down_revision: Union[str, None] = 'a1b2c3d4e5fb'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Step 1: Add new columns (nullable initially)
    op.add_column('ai_suggestion_jobs', sa.Column('entity_type', sa.String(length=50), nullable=True))
    op.add_column('ai_suggestion_jobs', sa.Column('entity_id', postgresql.UUID(as_uuid=True), nullable=True))
    
    # Step 2: Migrate existing data
    # Set entity_type='repository' and entity_id=repository_id for all existing rows
    op.execute("""
        UPDATE ai_suggestion_jobs 
        SET entity_type = 'repository', 
            entity_id = repository_id
        WHERE entity_type IS NULL
    """)
    
    # Step 3: Make columns NOT NULL
    op.alter_column('ai_suggestion_jobs', 'entity_type', nullable=False)
    op.alter_column('ai_suggestion_jobs', 'entity_id', nullable=False)
    
    # Step 4: Create indexes on new columns
    op.create_index('ix_ai_suggestion_jobs_entity_type', 'ai_suggestion_jobs', ['entity_type'])
    op.create_index('ix_ai_suggestion_jobs_entity_id', 'ai_suggestion_jobs', ['entity_id'])
    
    # Step 5: Create composite index for efficient queries
    op.create_index(
        'ix_ai_suggestion_jobs_entity_type_id_field',
        'ai_suggestion_jobs',
        ['entity_type', 'entity_id', 'field_name']
    )
    
    # Step 6: Drop old repository_id foreign key constraint
    op.drop_constraint('ai_suggestion_jobs_repository_id_fkey', 'ai_suggestion_jobs', type_='foreignkey')
    
    # Step 7: Drop old repository_id index
    op.drop_index('idx_ai_suggestion_jobs_repository_id', table_name='ai_suggestion_jobs')
    
    # Step 8: Drop repository_id column
    op.drop_column('ai_suggestion_jobs', 'repository_id')


def downgrade() -> None:
    # Step 1: Add repository_id column back (nullable initially)
    op.add_column('ai_suggestion_jobs', sa.Column('repository_id', postgresql.UUID(as_uuid=True), nullable=True))
    
    # Step 2: Migrate data back (only for repository entity_type)
    op.execute("""
        UPDATE ai_suggestion_jobs 
        SET repository_id = entity_id
        WHERE entity_type = 'repository'
    """)
    
    # Step 3: Make repository_id NOT NULL (assuming all rows are repositories in downgrade)
    op.alter_column('ai_suggestion_jobs', 'repository_id', nullable=False)
    
    # Step 4: Recreate foreign key constraint
    op.create_foreign_key(
        'ai_suggestion_jobs_repository_id_fkey',
        'ai_suggestion_jobs',
        'ropa_repositories',
        ['repository_id'],
        ['id'],
        ondelete='CASCADE'
    )
    
    # Step 5: Recreate repository_id index
    op.create_index('idx_ai_suggestion_jobs_repository_id', 'ai_suggestion_jobs', ['repository_id'])
    
    # Step 6: Drop composite index
    op.drop_index('ix_ai_suggestion_jobs_entity_type_id_field', table_name='ai_suggestion_jobs')
    
    # Step 7: Drop entity_id index
    op.drop_index('ix_ai_suggestion_jobs_entity_id', table_name='ai_suggestion_jobs')
    
    # Step 8: Drop entity_type index
    op.drop_index('ix_ai_suggestion_jobs_entity_type', table_name='ai_suggestion_jobs')
    
    # Step 9: Drop new columns
    op.drop_column('ai_suggestion_jobs', 'entity_id')
    op.drop_column('ai_suggestion_jobs', 'entity_type')

