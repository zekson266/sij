"""rename_data_element_activity_id_to_processing_activity_id

Revision ID: 612a9d01e9a1
Revises: 27ec34a1cc85
Create Date: 2026-01-19 23:42:21.123456

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '612a9d01e9a1'
down_revision: Union[str, None] = '27ec34a1cc85'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Rename activity_id to processing_activity_id in ropa_data_elements table
    op.alter_column('ropa_data_elements', 'activity_id', new_column_name='processing_activity_id')


def downgrade() -> None:
    # Rename processing_activity_id back to activity_id
    op.alter_column('ropa_data_elements', 'processing_activity_id', new_column_name='activity_id')
