"""add_guest_contact_fields_to_appointments

Revision ID: 194a74255636
Revises: 7cd90491c305
Create Date: 2025-12-30 17:46:38.974545

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '194a74255636'
down_revision: Union[str, None] = '7cd90491c305'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add guest contact fields to appointments table
    # These fields store contact info for anonymous (guest) bookings
    # Nullable because authenticated users use user_id for contact info
    op.add_column('appointments', sa.Column('guest_name', sa.String(length=255), nullable=True))
    op.add_column('appointments', sa.Column('guest_email', sa.String(length=255), nullable=True))
    op.add_column('appointments', sa.Column('guest_phone', sa.String(length=50), nullable=True))

    # Create index on guest_email for searching guest bookings
    op.create_index(op.f('ix_appointments_guest_email'), 'appointments', ['guest_email'], unique=False)


def downgrade() -> None:
    # Drop index
    op.drop_index(op.f('ix_appointments_guest_email'), table_name='appointments')

    # Drop guest contact columns
    op.drop_column('appointments', 'guest_phone')
    op.drop_column('appointments', 'guest_email')
    op.drop_column('appointments', 'guest_name')

