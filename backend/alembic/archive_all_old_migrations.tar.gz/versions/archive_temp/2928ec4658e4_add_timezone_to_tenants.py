"""add timezone to tenants

Revision ID: 2928ec4658e4
Revises: 5e0c33ea412f
Create Date: 2025-12-28 01:23:08.759023

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '2928ec4658e4'
down_revision: Union[str, None] = '5e0c33ea412f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add timezone column to tenants table
    op.add_column('tenants', sa.Column('timezone', sa.String(length=50), nullable=False, server_default='UTC'))

    # Create index on timezone for potential queries
    op.create_index(op.f('ix_tenants_timezone'), 'tenants', ['timezone'], unique=False)


def downgrade() -> None:
    # Drop index
    op.drop_index(op.f('ix_tenants_timezone'), table_name='tenants')

    # Drop timezone column
    op.drop_column('tenants', 'timezone')

