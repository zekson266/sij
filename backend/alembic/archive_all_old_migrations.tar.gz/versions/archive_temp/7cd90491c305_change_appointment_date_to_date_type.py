"""change appointment_date to date type

Revision ID: 7cd90491c305
Revises: 2928ec4658e4
Create Date: 2025-12-28 01:27:24.172105

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '7cd90491c305'
down_revision: Union[str, None] = '2928ec4658e4'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Change appointment_date from TIMESTAMP to DATE
    # PostgreSQL can directly cast TIMESTAMP to DATE
    op.alter_column('appointments', 'appointment_date',
                   existing_type=sa.DateTime(),
                   type_=sa.Date(),
                   existing_nullable=False,
                   postgresql_using='appointment_date::date')


def downgrade() -> None:
    # Revert appointment_date from DATE to TIMESTAMP
    # Set time to midnight when converting back
    op.alter_column('appointments', 'appointment_date',
                   existing_type=sa.Date(),
                   type_=sa.DateTime(),
                   existing_nullable=False,
                   postgresql_using="appointment_date::timestamp")

